# Testing

## Test Cases Including 1 User
*Go from step 1 to 68 in one run*
### Test 1: User (Seller) Sign-up and Store Creation/Deletion
1. Connect to the server using “**localhost**” for IP address and “**80**” for the port 
2. Sign up with a new username “**user**” and new password “**pass**” 
3. Select “Seller” in the dropdown menu 
4. Click “**Sign up**” 
5. Enter the name of the first store as “**store**” 
6. Click “**Enter**” 
7. Add “**store2**” as the next store 
8. Remove “**store**” 
9. Select “**store2**” in the dropdown menu 
10. Click “**Logout**”


Expected Results: Server stores username and password, as well as adding and then deleting “store” and registering the “store2” store.

Test Result: Passed IF “Users.json” contains these terms listed in Expected Result

Testing status: *passed*

### Test 2: User (Customer) Send/Edit/Delete/Import/Export
11. Sign up as a new user (Click “**Sign up**”)
12. Sign up with a new username “**user2**” and new password “pass” 
13. Select “**Customer**” in the dropdown menu 
14. Click “**Sign up**” 
15. Click “**Message Stores**” 
16. On the Select seller page select the seller named “**user**” 
17. In the select stores page select “**store2**” 
18. Click “**New Conversation**” 
19. In the “**Send**” tab, type “**Hello, World!**” 
20. Click “**Send Message**” 
21. In the “**Send**” tab, type “**Hello, World! 2**” 
22. Click “**Send Message**” 
23. Select the “**Delete**” tab 
24. Type “**0**” for the line number to delete and click “**delete**” 
25. Select the “**Edit**” tab 
26. Type “**0**” for the line number to edit and type “Edited Message!” in the second text field 
27. Click “**Send Edit**” 
28. Create a text file named “**message.txt**” inside the project folder 
29. Inside the “**message.txt**” write “**Hello, World! 3**” 
30. Select the “**Import**” tab 
31. Enter “**message.txt**” into the text field and click “**Import**” 
32. Click “**Send message**” 
33. Select the “**Export**” tab 
34. Type “**export**” into the text field and click the “**Export**” button 
35. Click “**Back**” and then “**Refresh**” to show the store that has been messaged 
36. Click “**Back**” and then “**Back**” and then “**Logout**”



Expected Results: Server stores username and password in Users.json, as well as storing the sent messages, edited 
messages, and deleted messages (flagged and not shown) in “user2,store2.txt” and store2,user2.txt. Imported file should be imported into the “Send” tab, and the exported file “export.csv” should be contained in the project. Refresh button should show the user “user” to be in the “previous conversations” list.

Testing status: *passed*

### Test 3: User (Seller) Send Messages and Secret Blocking
37. Click “**Login**” 
38. Login using “**user**” and “**pass**” 
39. Select “**store2**” 
40. Click “**Message customer**” 
41. Click “**user2**” under the messaged customers list 
42. Select “**Previous conversations**” 
43. Send “**World, Hello!**” in the text field 
44. Send “**World, Hello! 1**” in the text field 
45. Send “**World, Hello! 2**” in the text field 
46. Select the “**Block**” tab 
47. Click “**Block**” 
48. Click “**Back**” 
49. Click “**Back**” 
50. Click “**Logout**”

Expected Results: Previous conversation should be shown in the client, and the server should now contain the three 
new messages sent to user “user2” (in both chat-log files). User “user2” is now conversation blocked by user “user”. “LogFileNames.txt” contains:
user2,store2.txt;2
store2,user2.txt;1

Testing status: *passed*

### Test 4: User Invisibility and Global Blocking
51. Login as user with username “**user**” and password “**pass**” 
52. Click “**Settings**”
53. Select “**user2**” under the visibility dropdown menu
54. Select “**Become invisible to**”
55. Click “**Back**”
56. Click “**Logout**”
57. Login as user2 with username “**user2**” and password “**pass**” 
58. Select “**Message Stores**”

Invisibility Expected Result: “**user**” is not visible for selection in the seller selection dropdown.

59. Click “**Back**” 
60. Select “**Settings**” 
61. Select “**user**” under the non-blocked users dropdown menu 
62. Select “**Block user**” 
63. Click “**Back**” 
64. Click “**Logout**” 
65. Log back in as “**user**” with username “**user**” and password “**pass**” 
66. Select “**store2**” 
67. Click “**Message Customers**” 
68. Select “**user2**” in Conversations already started

Global Blocking Expected Result: “**user2**” is blocked globally by “**user**” and is not able to message “**user**”. A pop-up error should show up.
 
Testing status: *passed both*


## Test Cases Including 2+ Concurrent Users:

**BEFORE STARTING TEST CASE 5:**    
- Delete All “.txt” files inside of “Data/Convos/” 
- Delete the text and all whitespace in “Users.json” and “LogFileNames.txt” 
- Close and Re-run the Server and Client 
- Run a second Client as well
- *Go from step 1 to 40 in one run*
### Multiple Users Test 1: Multiple Clients and Refresh Button

1. Launch the Server and two or more clients 
2. Sign in to each client using IP “**localhost**” and port “**80**” 
3. On Client1 sign in as a new SELLER with username “**user**” and pass “**pass**” 
4. On Client1 add “**store1**” as the first store 
5. On Client2 sign in as a new CUSTOMER with username “**user2**” and pass “**pass**” 
6. On Client1 click “**Message Customers**” 
7. On Client1 select “**user2**” and then click “**New Conversation**” 
8. On Client2 select “**Message Stores**”
9. On Client2 select “**store1**” and then click “**Previous Conversation**” (Since it was started by the other user)
10. On Client1 send the message “**Hello, World!**” 
11. On Client2 click “**Click to Refresh Chat!**”

Expected Result: Message “Hello, World!” is shown as sent by “store1” on both clients.
Testing status: *passed*

### Multiple Users Test 2: Deletion Visibility on Multiple Clients

12. On Client2 send the message “**What’s up?**” 
13. On Client2 go to the “**Delete**” tab 
14. To test edge cases, On Client2 enter a number that is out of the range of the displayed line numbers (less than 0 or greater than 1 considering the previously sent messages). 
15. To test edge cases, On Client2 try to delete a message that was not sent by “**user2**” 
16. On Client2 actually delete the sent message this time by selecting “**1**” and clicking “**Delete**”. 
17. On both clients go to the “**Send**” tab and click “**Click to Refresh Chat!**”

Expected Result: On Client1, there should be 2 messages TOTAL, On Client2 there should be a single message from “store1”.

### Multiple Users Test 3: Editing Visibility on Multiple Clients

18. On Client1 select the “**Edit**” tab 
19. To test edge cases, On Client1 enter a number that is out of the range of the displayed line numbers (less than 0 or greater than 1 considering the previously sent messages). 
20. To test edge cases, On Client1 try to edit a message that was not sent by “store1” 
21. To test edge cases, On Client1 enter nothing into the message box, but select line “**0**”. 
22. To test edge cases, On Client1 enter nothing into the line box, but add “**edited message**” into the message box. 
23. On Client1 actually edit the message by entering line “**0**” and entering “**edited message**” into the message box. Click “**Send Edit**”. 
24. On both Clients, select the “**Send**” tab and click “**Click to Refresh Chat!**”

Expected Result: Both clients should display line 0 as “**edited message**” sent from “**store1**”.
Testing status: *passed*

### Multiple Users Test 4: Importing and Sending an Imported Message on Multiple Clients

25. On Client2 select the “**Import**” tab 
26. “**message.txt**” exists in the project file for this test. 
27. On Client2 enter “message.txt” into the text box for importing and click “**import**” 
28. On Client2 you should now be at the “**Send**” tab and click “**Send message**” 
29. On Client1 go to the “**Send**” tab and click “**Click to Refresh Chat!**”

Expected Result: Both clients display a new message from “user2” that says “Hello World!” (the contents of “message.txt”).

Testing status: *passed*

### Multiple Users Test 5: Exporting Multiple Clients
30. On Client1 click the “**Export**” tab and click “**Export this conversation**”

Expected Result: A file appears in the project directory named “store1,user2.csv” that contains the chat in a spreadsheet-style format.

Testing status: *passed*

### Multiple Users Test 6: Localized Blocking on Multiple Clients 

31. On Client2 select the “**Block**” tab 
32. On Client2 click “**Block**” 
33. On Client1 click the “**Send**” tab 
34. On Client1 attempt to send the message “**Can you see this?**” and click “**Send message**” 
35. On Client2 click the “**Send**” tab and click “**Click to Refresh Chat**”

Expected Result: Client2 does not see the message sent by “**store1**”. Client1 still displays the message from “**store1**”.

Testing status: *passed*

### Multiple Users Test 7: Message Visibility During Blocking and Unblocking
36. On Client2 select the “**Block**” tab 
37. On Client2 click “**Unblock**”
38. On Client2 select the “**Send**” tab 
39. On Client1 attempt to send the message “**Can you see this?2**” and click “**Send message**”
40. On Client2 click “**Click to Refresh Chat!**”

Expected Result: Client2 should still not see the blocked message “Can you see this?”, however, it should see the new message after unblocking “store1” “Can you see this?2”.

Testing status: *passed*
