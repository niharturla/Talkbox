# CS180 Project 5
## Compile Instructions
Intellij should read the pom.xml and recognize the project as a Maven Project.    
It should automatically begin to add the dependencies to the project.    
Just to be sure, in the top right corner of the Intellij window.     
Click the 'Reload all Maven Projects button'. Under 'External Libraries' you should see all the added dependencies.   

To run our program in the Project Structure make your way to:   
src -> main -> java -> Server.java. Run Server.java.
Then go to Client.java and run it.

## Submission
Project 5 Report was submitted by Matthew Yang    
Project 5 Code was submitted by Matthew Yang   
Project 5 Presentation was submitted by Jack Feeney  


## Testing
All testing is found in Testing.md
## Classes
### User.java
#### Functionality
This class serves as the object that every user is managed by. It can create new users based on the role, username, password, and stores (if their role is a seller entered in through the constructor. It can also take in single formatted strings to contruct a user. The user class also manages the invisibilityHitList and blockingList, and every field that this class manages can be accessed/managed by getter and setter methods.
#### Relationships To Others
Both Client.java and Server.java utilize the User class to manage how they display/handle information that is quintessential to their functions. User.java utilizes Logging.java for some of its methods to log the changes made in these methods to the Users.json. Logging.java also takes in a CopyOnWriteArrayList of User objects as a parameter for its writeJSON method and returns a CopyOnWriteArrayList of User objects for its readJSON method
### Conversation.java
#### Functionality
This class manages all the messaging features of the app. It can create conversations between two Users and store them into 2 unique chat logs that the Users can modify to their will (up to their own messages) as well
#### Relationships To Others
Conversation is used in the Server.java class where its methods are called in order to create a chatting system between a buyer and seller given a reciever name and a sender name.
### Client.java
#### Functionality
This class serves the purpose of connecting with the Server socket, displaying a GUI that takes in information that will be sent to the Server, sending commands to the Server, and displaying information sent back from the server on the GUI.
#### Relationships To Others
This class uses the User class to manage user related data and the Page class to manage the different pages of the GUI. Client.java also sends packets through a Printwriter to the Server class in order to execute commands on the server.
### Page.java
#### Functionality
Page.java is a helper class that extends JPanel that is basically like a template for each GUI page and is called when the client needs to load a new page in the GUI.
#### Relationships To Others
Client.java uses this class as a template for each new GUI page and will call an object of its type to display another page on the GUI.
### Server.java
#### Functionality
Server.java takes in a socket connection from instances of Client.java and recieves commands from the client and performs actions like global blocking/secret blocking/invisibility, send/editing/deleting/importing messages, adding/modifying users, exporting conversations, and sending data back to the client in order to display the information.
#### Relationships To Others
Server.java sends/recieves packets to and from the Client and performs actions utilizing the Logging, User, Conversation, and Blocking classes. 
### Logging.java
#### Functionality
Logging.java handles all the reading and writing to the Users.json file by taking in and return CopyOnWriteArrayLists of User objects. It also looks for and reads the contents of a specific chat log and returns the contents as an ArrayList of Strings (1 String for each line on the chat log)
#### Relationships To Others
Logging.java is utilizing mostly by the Server class, so the server and the User.json can both be as updated as possible with new changes to the users stored inside of them. Logging is also called inside of the User class when specific methods are made that need to be updated as soon as the method is complete.
### Blocking.java
#### Functionality
BlockingPage.java handles the local/secret blocking and unblocking of conversations between a store and a customer (NOT the overall user of both, i.e a store can block a customer, but the owner of that store can still be contacted via their other stores and visa versa)
#### Relationships To Others
BlockingPage.java utilizes Conversation objects to get the information necessary to perform its methods and edit LogFileNames.txt properly. It is also called by the Server when the client sends a packet requesting to utilize a method in BlockPage.java
