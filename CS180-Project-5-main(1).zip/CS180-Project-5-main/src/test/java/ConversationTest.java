import org.junit.jupiter.api.Test;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;


import static org.junit.jupiter.api.Assertions.*;

class ConversationTest {

    @Test
    void getLogFileNamesTest() {
        CopyOfConversation conversation = new CopyOfConversation("matthew", "WalmartTest");
        conversation.fillNamesList("src/test/java/LogFileNameTest.txt");
        ArrayList<String> test = new ArrayList<>();
        test.add("matthew,WalmartTest.txt;0");
        test.add("WalmartTest,matthew.txt;0");
        test.add("matthew,WalmartForDeleteEdit.txt;0");
        test.add("WalmartForDeleteEdit,matthew.txt;0");
        test.add("customer,store1.txt;0");
        test.add("store1,customer.txt;0");
        assertArrayEquals(new ArrayList[]{test}, new ArrayList[]{conversation.getLogFileNames()});
    }

    @Test
    void checkConvoPairExistsTest() {
        CopyOfConversation conversation = new CopyOfConversation("NotMatthew", "NotWalmart");
        conversation.fillNamesList("src/test/java/LogFileNameTest.txt");
        assertEquals(false, conversation.checkConvoPairExists());

    }

    @Test
    void getNumLinesTest() {
        CopyOfConversation conversation = new CopyOfConversation("matthew", "WalmartTest");
        conversation.fillNamesList("src/test/java/LogFileNameTest.txt");
        assertEquals(15, conversation.getNumLines("src/test/java/matthew,WalmartTest.txt"));
    }

    @Test
    void getNumOfNonDeletedLinesTest() {
        CopyOfConversation conversation = new CopyOfConversation("matthew", "WalmartTest");
        conversation.fillNamesList("src/test/java/LogFileNameTest.txt");
        assertEquals(13, conversation.getNumOfNonDeletedLines("src/test/java/matthew,WalmartTest.txt"));
    }

    @Test
    void fileNameTest() {
        CopyOfConversation convo = new CopyOfConversation("matthew", "WalmartTest");
        convo.fillNamesList("Data/LogFileNames.txt");
        assertEquals("matthew" + "," + "WalmartTest", convo.fileName(1));

    }

    @Test
    void copyTest() {
        CopyOfConversation convo = new CopyOfConversation("matthew", "WalmartTest");
        convo.fillNamesList("src/test/java/LogFileNameTest.txt");

        ArrayList<String> texts = new ArrayList<>();
        texts.add("0;12-10-2023 15:21:38:38;[WalmartTest] - Hello!;0");
        texts.add("1;12-10-2023 15:21:47:47;[WalmartTest] - My name is John;1");
        texts.add("2;12-10-2023 15:22:06:06;[WalmartTest] - What would you like to buy?;2");
        texts.add("3;12-10-2023 15:22:14:14;[WalmartTest] - Walmart has everything you need!;3");
        texts.add("4;12-10-2023 15:23:30:30;[matthew] - Hi John!;4");
        texts.add("5;12-10-2023 15:23:36:36;[matthew] - I'm matt;5");
        texts.add("6;12-10-2023 15:23:43:43;[matthew] - I would like to purchase;6");
        texts.add("7;12-10-2023 15:23:48:48;[matthew] - Som basdfadfgels;D");
        texts.add("8;12-10-2023 15:23:48:48;[matthew] - Some bagels;7");
        texts.add("9;12-10-2023 15:23:59:59;[matthew] - lso orasdfge juice;D");
        texts.add("10;12-10-2023 15:23:59:59;[matthew] - Also orange juice;8");
        texts.add("11;12-10-2023 15:24:39:39;[WalmartTest] - Ok;9");
        texts.add("12;12-10-2023 15:24:48:48;[WalmartTest] - I have put down your order;10");
        texts.add("13;12-10-2023 15:25:08:08;[WalmartTest] - Please come pick up in 30 minutes!;11");
        texts.add("14;12-10-2023 15:25:42:42;[matthew] - Ok thank you!;12");
        assertEquals(texts, convo.copy(1));
    }

    @Test
    void deleteMessageTest() {
        //reset the json we are using as previous tests will mess it up
        try {

            ArrayList<String> list = new ArrayList<>();
            list.add("0;12-10-2023 15:21:38:38;[WalmartTest] - Hello!;0");
            list.add("1;12-10-2023 15:21:47:47;[WalmartTest] - My name is John;1");
            list.add("2;12-10-2023 15:22:06:06;[WalmartTest] - What would you like to buy?;2");
            list.add("3;12-10-2023 15:22:14:14;[WalmartTest] - Walmart has everything you need!;3");
            list.add("4;12-10-2023 15:23:30:30;[matthew] - Hi John!;4");
            list.add("5;12-10-2023 15:23:36:36;[matthew] - I'm matt;5");
            list.add("6;12-10-2023 15:23:43:43;[matthew] - I would like to purchase;6");
            list.add("7;12-10-2023 15:23:48:48;[matthew] - Som basdfadfgels;D");
            list.add("8;12-10-2023 15:23:48:48;[matthew] - Some bagels;7");
            list.add("9;12-10-2023 15:23:59:59;[matthew] - lso orasdfge juice;D");
            list.add("10;12-10-2023 15:23:59:59;[matthew] - Also orange juice;8");
            list.add("11;12-10-2023 15:23:59:59;[matthew] - DELETEME;9");
            list.add("12;12-10-2023 15:24:39:39;[WalmartTest] - Ok;10");
            list.add("13;12-10-2023 15:24:48:48;[WalmartTest] - I have put down your order;11");
            list.add("14;12-10-2023 15:25:08:08;[WalmartTest] - Please come pick up in 30 minutes!;12");
            list.add("15;12-10-2023 15:25:42:42;[matthew] - Ok thank you!;13");
            FileOutputStream fos = null;

            fos = new FileOutputStream("src/test/java/matthew,WalmartForDeleteEdit.txt", false);
            PrintWriter pw = new PrintWriter(fos);
            for (int i = 0; i < list.size(); i++) {
                pw.println(list.get(i));
            }
            pw.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }


        CopyOfConversation convo = new CopyOfConversation("matthew", "WalmartForDeleteEdit");
        convo.fillNamesList("src/test/java/LogFileNameTest.txt");
        String file = "src/test/java/matthew,WalmartForDeleteEdit.txt";
        assertEquals(14, convo.getNumOfNonDeletedLines(file));
        assertEquals(true, convo.deleteMessage(9));
    }

    @Test
    void editMessageTest() {
        CopyOfConversation convo = new CopyOfConversation("matthew", "WalmartForDeleteEdit");
        convo.fillNamesList("src/test/java/LogFileNameTest.txt");
//Edit their line
        assertEquals(false, convo.editMessage(3, "EDIT"));
        //Edit your line
        assertEquals(true, convo.editMessage(4, "EDIT"));
    }
}
