import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.*;
import java.util.ArrayList;

/**
 * This is an exact copy of Conversation.java. Just renamed the class. It's needed since some of the file paths in the
 * actual program classes are hard coded to go to Data/Convos. We want to store the test data files separately (in
 * this test folder).
 */
public class CopyOfConversation {

    private String sender;
    private String receiver;

    private ArrayList<String> LogFileNames = new ArrayList<>();

    //Creates a Message object with two attributes a Global.User sender and a Global.User receiver.
    public CopyOfConversation(String sender, String receiver) {
        this.sender = sender;
        this.receiver = receiver;
    }

    //Get methods.
    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }


    //After creating Message object make sure to call this once. Adds log files names from text file to ArrayList
    // belonging to Message class. Makes it easier to reference.
    public void fillNamesList(String filename) {
        try {
            File f = new File(filename);
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String line = br.readLine();

            LogFileNames = new ArrayList<>();

            while (line != null) {
                LogFileNames.add(line);
                line = br.readLine();
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public ArrayList<String> getLogFileNames() {
        return LogFileNames;
    }

    //Call this method before creating new pair to prevent duplicate pairs.
    public boolean checkConvoPairExists() {
        String aToB = this.fileName(1) + ".txt";
        String bToA = this.fileName(2) + ".txt";

        for (int i = 0; i < LogFileNames.size(); i++) {
            if (LogFileNames.get(i).substring(0,
                    LogFileNames.get(i).length() - 2).equals(aToB) || LogFileNames.get(i).substring(0,
                    LogFileNames.get(i).length() - 2).equals(bToA)) {
                return true;
            }
        }
        return false;
    }

    //Creates new conversation files.
    //The created files are in the format 'a,b.txt' and 'b,a.txt'.
    public void createNewConvoPair() {
        try {

            String aToB = fileName(1) + ".txt";

            this.addToLogFileNames(aToB + ";0");
            PrintWriter newThread = new PrintWriter(new FileWriter("src/test/java/" + new File(aToB)));
            newThread.close();

            String bToA = fileName(2) + ".txt";
            this.addToLogFileNames(bToA + ";0");
            PrintWriter newThread2 = new PrintWriter(new FileWriter("src/test/java/" + new File(bToA)));
            newThread2.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Adds a conversation log filename (a,b.txt) into a text file. Stored reference of every conversation log.
    public void addToLogFileNames(String convoName) {
        try {
            File logFileNames = new File("src/test/java/LogFileNameTest.txt");
            FileOutputStream fos = new FileOutputStream(logFileNames, true);
            PrintWriter pw = new PrintWriter(fos);
            pw.println(convoName);
            pw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Returns the number of lines in a file.
    public int getNumLines(String fileName) {
        int count = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line = br.readLine();
            while (line != null) {
                count++;
                line = br.readLine();
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;

    }

    public int getNumOfNonDeletedLines(String fileName) {
        int count = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line = br.readLine();
            while (line != null) {
                if (!line.substring(line.length() - 1).equals("D")) {
                    count++;
                }
                line = br.readLine();
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;

    }

    //  addMessage appends the String message to both Conversation logs.
    //  Conversation are formatted like this:
    //  line ids are shared for both files. Unlike line numbers Line IDs do not change.
    //  [line ID (start at 0)];[date/time];['[username]'] - [contents];[Display Num]
    //  5;07-11-2023;12:05:52;Matthew - How are you doing?
    // EDIT
    // We are implementing an updated logging system. This is necessary for client-server interaction + multi-threading
    // as the line numbers displayed on the client are not the most current line numbers in the server.
    // Example of issue:
    //There is a user called bob.
    //bob is sending several messages to a receiver (lets just call them carl).
    //The all data is stored in the server. So the logfile bob,carl.txt belongs to the server.
    //bob sends the following
    // 0. a
    // 1. b
    // 2. c
    //Then bob decides to delete line 0, "a"
    //the command is sent to the server.
    // The line is deleted and log rewritten
    //now the log looks like this:
    // 0. b
    // 1. c
    //bob immediately decides to edit c to d.
    //He inputs edit line 2
    //This command is sent to the server. However, when the server reads the command and executes it, a error appears.
    // Since the line numbers were rewritten during deletion, line 2 does not exist in the log file.
    //Now, one intuitive fix is to force updates to line numbers client side. After any changes to the log on the
    // server, send that most updated version to the client, so that the client always has the most updated version
    // to reference. This is a good solution.
    // However, in a multithreaded scenario, this solution becomes flawed.
    //
    // Now to prevent race-conditions between threads we mandated that all adding, editing, and deleting actions are
    // to be synchronized. Only on thread/client should be able to access these methods at a time. In other words,
    // these commands become queued in order by which a client calls them.
    //
    //Therefore, there may be cases where both users are making changes to their log files at the same time and . If we
    // update both clients to display the changes as soon as they are made (with rewriting line numbers), then one
    // server will...
    //
    //There are also edge cases to account for where, lets say two lines sent by a user, contain the same message and
    // time stamp. This will confuse the edit functionality of the server (previously we used timestamps and
    // contents to update lines in both log files.
    //
    // In general, it is better to preserve all data rather than deleting and rewriting. This basically eliminates the
    // possibility of any data leakage.
    public void addMessage(String message) {
//before everything check block status
        CopyOfBlocking block = new CopyOfBlocking();
        int status = block.returnBlockingStatus(this);


        String aToB = "Data/Convos/" + fileName(1) + ".txt";
        String bToA = "Data/Convos/" + fileName(2) + ".txt";

        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss:ss");
        String formattedDate = myDateObj.format(myFormatObj);

        String aToBLineID = String.valueOf(getNumLines(aToB));
        String bToALineID = String.valueOf(getNumLines(bToA));

        String aToBDisplayNum = String.valueOf(getNumOfNonDeletedLines(aToB));
        String bToADisplyNum = String.valueOf(getNumOfNonDeletedLines(bToA));

        String updateMessageAToB =
                aToBLineID + ";" + formattedDate + ";" + "[" + sender + "]" + " - " + message + ";" + aToBDisplayNum;
        String updateMessageBToA;
        if (status == 2 || status == 3) {
            updateMessageBToA = bToALineID + ";" + formattedDate + ";" +
                    "[" + sender + "]" + " - " + message + ";" + "D";
        } else {
            updateMessageBToA =
                    bToALineID + ";" + formattedDate + ";" +
                            "[" + sender + "]" + " - " + message + ";" + bToADisplyNum;
        }

        try {
            File f = new File(aToB);
            FileOutputStream fos = new FileOutputStream(f, true);
            PrintWriter pw = new PrintWriter(fos, true);
            pw.println(updateMessageAToB);

            File f2 = new File(bToA);
            FileOutputStream fos2 = new FileOutputStream(f2, true);
            PrintWriter pw2 = new PrintWriter(fos2, true);
            pw2.println(updateMessageBToA);

            pw.close();
            pw2.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    //Return a partially formatted file name. Either a,b or b,a no ".txt" or full directory path (also could be seen
    // as sender,receiver and receiver, sender). Two paths are taken. If sender is a seller then receiver is a
    // customer. If sender is a customer then receiver is a seller.
    public String fileName(int choiceP) {
        String fileName = null;
        if (choiceP == 1) {
            //sender,receiver
            fileName = sender + "," + receiver;
        } else {
            //receiver,sender
            fileName = receiver + "," + sender;
        }
        return fileName;
    }

    //This method copies all data within the log file specified into an ArrayList of Strings and returns the
    // ArrayList. Two paths can be taken: copy sender,receiver.txt or copy receiver,sender.txt
    public ArrayList<String> copy(int choiceP) {
        ArrayList<String> copy;
        if (choiceP == 1) {
            //copy sender,receiver.txt
            copy = new ArrayList<>();
            try {
                BufferedReader br =
                        new BufferedReader(new FileReader("src/test/java/" + fileName(choiceP) + ".txt"));
                String line = br.readLine();
                while (line != null) {
                    copy.add(line);
                    line = br.readLine();
                }
                br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            //copy receiver,sender.txt
            copy = new ArrayList<>();
            try {
                BufferedReader br =
                        new BufferedReader(new FileReader("src/test/java/" + fileName(choiceP) + ".txt"));
                String line = br.readLine();
                while (line != null) {
                    copy.add(line);
                    line = br.readLine();
                }
                br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return copy;
    }

    //This method deletes the message with the specified lineNum. Senders can only delete their own Conversation. They do
    // not have permission to delete Conversation that Receivers have sent.
    public boolean deleteMessage(int lineNum) {
        //line num is display!!!
        ArrayList<String> copy;
        try {
            copy = copy(1);
            String fileName = "src/test/java/" + fileName(1) + ".txt";
            if (lineNum >= getNumOfNonDeletedLines(fileName)) {
                return false;
            }
            int i = -1;
            String target;
            do {
                i++;
                String[] list = copy.get(i).split(";", 4);
                target = list[3];
            } while (!(target.equals(String.valueOf(lineNum))));
            int lineID = i;
            String lineCopy = copy.get(lineID);

            if (lineCopy.split(";", 4)[2].contains("[" + this.sender + "]")) {
                lineCopy = lineCopy.substring(0, lineCopy.lastIndexOf(';')) + ";D";
                copy.set(lineID, lineCopy);
//We go to the specified lineID (it ='s index in copy ArrayList). To delete we are changing the lineNum to "D", then we
// will rename the rest of the line nums (display).
                int displyNum = lineNum;
                for (int j = lineID + 1; j < copy.size(); j++) {
                    String[] list2 = copy.get(j).split(";", 4);
                    String target2 = list2[3];
                    if (!target2.equals("D")) {
                        copy.set(j, list2[0] + ";" + list2[1] + ";" + list2[2] + ";" + displyNum);
                        displyNum++;
                    }
                }
                //Wipe the file.
                PrintWriter clear = new PrintWriter(fileName);
                clear.println();
                clear.close();
                //Now rewrite the file!
                FileOutputStream fos = new FileOutputStream(fileName);
                PrintWriter pw = new PrintWriter(fos);
                for (int k = 0; k < copy.size(); k++) {
                    pw.println(copy.get(k));
                }
                pw.close();
            } else {
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    //This method allows the current user (sender) to edit a message that they have previously sent. The message is
    // updated in both log files (sender,receiver.txt and receiver,sender.txt).
    public boolean editMessage(int lineNum, String newMessage) {
        //lineNum is display
        CopyOfBlocking block = new CopyOfBlocking();
        int status = block.returnBlockingStatus(this);

        String fileName = "src/test/java/" + fileName(1) + ".txt";
        String fileNameReceiver = "src/test/java/" + fileName(2) + ".txt";
        ArrayList<String> copy = copy(1);
        ArrayList<String> copyRec = copy(2);

        if (lineNum >= getNumOfNonDeletedLines(fileName)) {
            return false;
        }

        try {

            //search for the common line id

            int i = -1;
            String target;
            String[] list;
            do {
                i++;
                System.out.println(i);
                System.out.println(copy.get(i));
                list = copy.get(i).split(";", 4);
                target = list[3];
            } while (!(target.equals(String.valueOf(lineNum))));

            int lineID = i;
            //valididate that this is a a legal edit
            if (copy.get(lineID).split(";", 4)[2].contains("[" + this.sender + "]")) {

                //lineID is shared in both

                //5 07-11-2023 12:05:52 Matthew - How are you doing?
                //(format)
                LocalDateTime myDateObj = LocalDateTime.now();
                DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");

                String formattedDate = myDateObj.format(myFormatObj);


                String updateMessage =
                        lineID + ";" + formattedDate + ";" + "[" + sender + "]" + " - " + newMessage + ";";
                //Does not containt display nums yet!
                copy.set(lineID, updateMessage + lineNum);
                String updateMessageBToA;
                if (status == 2 || status == 3) {
                    updateMessageBToA = updateMessage + "D";
                } else {
                    String[] list2 = copyRec.get(lineID).split(";", 4);
                    int copyLineNum = Integer.parseInt(list2[3]);
                    updateMessageBToA =
                            updateMessage + copyLineNum;
                }
//in copyRec lineNum is different;
                copyRec.set(lineID, updateMessageBToA);


                //Wipe the files.
                PrintWriter clear = new PrintWriter(fileName);
                clear.println();
                clear.close();

                PrintWriter clearRec = new PrintWriter(fileNameReceiver);
                clearRec.println();
                clearRec.close();

                //Now rewrite the files!
                FileOutputStream fos = new FileOutputStream(fileName);
                PrintWriter pw = new PrintWriter(fos);
                for (int j = 0; j < copy.size(); j++) {
                    pw.println(copy.get(j));
                }
                pw.close();

                FileOutputStream fos2 = new FileOutputStream(fileNameReceiver);
                PrintWriter pw2 = new PrintWriter(fos2);
                for (int k = 0; k < copyRec.size(); k++) {
                    pw2.println(copyRec.get(k));
                }
                pw2.close();


            } else {
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }


    public void importFile(String importedFile) {
        try {
            int numLines = getNumLines("src/test/java/" + this.fileName(1) + ".txt");

            for (int i = 1; i <= 2; i++) {
                FileReader fr = new FileReader(importedFile);
                BufferedReader br = new BufferedReader(fr);
                FileOutputStream fos = new FileOutputStream("src/test/java/" + this.fileName(i)
                        + ".txt", true);
                PrintWriter pw = new PrintWriter(fos);
                LocalDateTime myDateObj = LocalDateTime.now();
                DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

                String formattedDate = myDateObj.format(myFormatObj);
                String[] arr = this.fileName(1).split(",");
                String line = br.readLine();
                int num = 0;
                while (line != null) {
                    pw.println((numLines + num) + " " + formattedDate + " [" + arr[0] + "] - " + line);
                    line = br.readLine();
                    num++;
                }
                pw.close();
                br.close();
            }

            System.out.println(importedFile + " successfully written into " + this.fileName(1) + ".txt");
        } catch (FileNotFoundException e) {
            System.out.println("Sorry, that file does not seem to exist. Please try again");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Export sender,receiver.txt as .csv file.
    public void exportCSV(String csvFileName) {
        try {
            FileReader fr = new FileReader("src/test/java/" + this.fileName(1) + ".txt");
            BufferedReader br = new BufferedReader(fr);


            PrintWriter newThread = new PrintWriter(new FileWriter(csvFileName));


            String line = br.readLine();


            while (line != null) {
                String[] lineList = new String[5];


                //Line will look like this:
                //5 07-11-2023 12:05:52 Nihar1 - How, are you doing?
                //Add the 4 parts of line to lineList array. Add commas to all but index 3.
                String[] lineArr = line.split(" ", 4);


                //Line Number
                lineList[0] = lineArr[0] + ",";


                //Date
                lineList[1] = lineArr[1] + ",";


                //Time
                lineList[2] = lineArr[2] + ",";


                String nameMessage = lineArr[3];


                String[] arrOfStrNameMessage = nameMessage.split(" - ", 2);
                for (int j = 0; j < arrOfStrNameMessage.length; j++) {
                    if (j == 0) {
                        lineList[j + 3] = arrOfStrNameMessage[j] + ",";
                    } else {
                        if (arrOfStrNameMessage[j].contains(",")) {
                            lineList[j + 3] = "\"" + arrOfStrNameMessage[j] + "\"";
                        } else {
                            lineList[j + 3] = arrOfStrNameMessage[j];
                        }
                    }
                }
                //Format the original line to be .csv readable.
                String csvLine = lineList[0] + lineList[1] + lineList[2] + lineList[3] + lineList[4];
                //Write the csvLine into the csvFile.
                newThread.println(csvLine);


                line = br.readLine();
            }
            br.close();
            newThread.close();
            System.out.println("Export successful!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
