import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class BlockingTest {
    @Test
    void blockingTest() {
        CopyOfConversation conversation = new CopyOfConversation("customer", "store1");
        CopyOfConversation conversation2 = new CopyOfConversation("store1", "customer");

        CopyOfBlocking blocking = new CopyOfBlocking();

        assertEquals(0, blocking.returnBlockingStatus(conversation));

        blocking.setFlag(conversation, true);
        assertEquals(1, blocking.returnBlockingStatus(conversation));
        assertEquals(2, blocking.returnBlockingStatus(conversation2));


        blocking.setFlag(conversation, false);

        assertEquals(0, blocking.returnBlockingStatus(conversation));

        blocking.setFlag(conversation, true);
        assertEquals(1, blocking.returnBlockingStatus(conversation));
        assertEquals(2, blocking.returnBlockingStatus(conversation2));

        blocking.setFlag(conversation2, true);
        assertEquals(3, blocking.returnBlockingStatus(conversation));
        assertEquals(3, blocking.returnBlockingStatus(conversation2));
        blocking.setFlag(conversation2, false);
        assertEquals(1, blocking.returnBlockingStatus(conversation));
        assertEquals(2, blocking.returnBlockingStatus(conversation2));
        blocking.setFlag(conversation, false);

    }
}