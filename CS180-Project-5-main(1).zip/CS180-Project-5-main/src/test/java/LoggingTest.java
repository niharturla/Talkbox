import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.*;

class LoggingTest {
    @Test
    void logTest(){
CopyOfLogging logger = new CopyOfLogging();
        CopyOnWriteArrayList<User> users = logger.readJSON("src/test/java/UsersForTest.json");
       assertEquals("customer", users.get(2).getUsername());
       users.get(2).setUsername("customerChanged");
       logger.writeJSON(users,"src/test/java/UsersForTest.json" );
       users = logger.readJSON("src/test/java/UsersForTest.json");
        assertEquals("customerChanged", users.get(2).getUsername());
        users.get(2).setUsername("customer");
        logger.writeJSON(users, "src/test/java/UsersForTest.json");
    }
}