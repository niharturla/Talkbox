import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;


/**
 * User.java
 * <p>
 * User holds all variables relative to each user that is in the program. This class logs all information
 * in a text file.
 *
 * @author CS 18000 Project 05 Group Lab 12-3 Team 58
 * @version 12-10-2023
 */
public class User implements Serializable {
    private String username; //Unique username of the User object
    private String password; //Password of the User object
    private String role; //Role of the user (Customer/Seller); formatted as ("C"/"S")
    private boolean firstGen; //Delineates whether account is newly created or returning
    private ArrayList<String> stores = new ArrayList<>(); //Holds sellers stores
    private String currentStore;
    private ArrayList<String> invisibleHitlist;
    private ArrayList<String> blockingList;

    public User() {
        super();
    }

    public User(String role, String username, String password, boolean firstGen) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.invisibleHitlist = new ArrayList<>();
        this.blockingList = new ArrayList<>();

        //If this user is being created and not called, add the user to the log
        if (firstGen) {
            firstGen = false;
        }
    }

    //Constructor for sellers who need an ArrayList of Stores and a current store property
    public User(String role, String username, String password, boolean firstGen, ArrayList<String> stores,
                String currentStore) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.stores = stores;
        this.currentStore = currentStore;
        this.invisibleHitlist = new ArrayList<>();
        this.blockingList = new ArrayList<>();
        //If this user is being created and not called, add the user to the log
        if (firstGen) {
            firstGen = false;
        }
    }

    //Allows us to take a toString and convert it into a User
    public User(String toString, boolean firstGen) {
        String[] parameters = toString.split("_");
        this.role = parameters[0];
        this.username = parameters[1];
        this.password = parameters[2];
        this.firstGen = firstGen;
        this.invisibleHitlist = new ArrayList<>();
        this.blockingList = new ArrayList<>();
        if (parameters.length > 3) {
            this.stores = new ArrayList<>();
            for (String s : parameters[3].split(",")) {
                this.stores.add(s);
                this.currentStore = null;
            }
        }
    }

    public String getRole() {
        return role;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public boolean isFirstGen() {
        return firstGen;
    }

    public void setUsername(String username) {
        this.username = username;
        //reload();
    }

    public void setPassword(String password) {
        this.password = password;
        //reload();
    }

    public void setRole(String role) {
        this.role = role;
        //reload();
    }

    public void setFirstGen(boolean firstGen) {
        this.firstGen = firstGen;
        //reload();
    }

    public ArrayList<String> getStores() {
        return stores;
    }

    public String getCurrentStore() {
        return currentStore;
    }

    public void setCurrentStore(String store) {
        currentStore = store;
        //reload();
    }

    public void addStore(String store) {
        stores.add(store);
        //reload();
    }

    public void removeStore(String store) {
        stores.remove(store);
        //reload();
    }

    public void setStores(ArrayList<String> stores) {
        this.stores = stores;
        //reload();
    }

    public ArrayList<String> getInvisibleHitlist() {
        return invisibleHitlist;
    }

    public ArrayList<String> getBlockingList() {
        return blockingList;
    }

    public void addInvisibleHitlist(String username) {
        invisibleHitlist.add(username);
        //reload();
    }

    public void removeInvisibleHitlist(String username) {
        invisibleHitlist.remove(username);
        //reload();
    }

    public void addToBlockList(String username) {
        blockingList.add(username);
    }

    public void removeFromBlockList(String username) {
        blockingList.remove(username);
    }

    public String toString() {
        String toString = "";
        //Turns the User object into a String that can be added to the log
        //or used to check a log
        if (role.equals("C")) {
            toString = role + "_" + username + "_" + password;
        } else {
            toString = role + "_" + username + "_" + password + "_";
            for (String store : stores) { //Append the stores at the end of the toString when user is a seller
                // with store array
                toString += store + ",";
            }
            toString = toString.substring(0, toString.length() - 1);
        }
        return toString;
    }

    //Checks if the User u is equivalent to this user using the toString
    public boolean equals(User u) {
        if (u.toString().equals(this.toString())) {
            return true;
        }
        return false;
    }

    //addUser will only be called in the signup process. There will be a user called currentUser declared in our
    // application class. In the signup process, we will get valid input from the physical user (i.e: role, valid
    // username, valid password, etc.) and then initialize currentUser. Then use the currentUser obj. to call addUser
    // . currentUser is adding itself to the Users.json file.
    public void addUser(User user) {
        Logging addToLog = new Logging();
        CopyOnWriteArrayList<User> users = addToLog.readJSON("Data/Users.json");
        users.add(user);
        addToLog.writeJSON(users, "Data/Users.json");
    }

    public void deleteUser(User user) {
        Logging deleteFromLog = new Logging();
        CopyOnWriteArrayList<User> users = deleteFromLog.readJSON("Data/Users.json");
        int index = -1;
        do {
            index++;
        } while (user.getUsername() != users.get(index).getUsername());
        users.remove(index);
        deleteFromLog.writeJSON(users, "Data/Users.json");
    }

    private void reload() {
        Logging reload = new Logging(); //Makes a new Logging object for the sake of reloading

        CopyOnWriteArrayList<User> users = reload.readJSON("Data/Users.json");
        //Create a list of users that's currently in the JSON right not

        //Iterates through the list to find the unupdated user
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(this.username)) {
                users.set(i, this);
            }
        }

        reload.writeJSON(users, "Data/Users.json"); //rewrites the JSON to have the new user
    }
}
