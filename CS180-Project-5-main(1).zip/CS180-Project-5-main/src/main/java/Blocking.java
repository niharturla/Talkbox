import java.io.*;
import java.util.ArrayList;

/**
 * Blocking.java
 * <p>
 * This class houses methods for Secret Blocking/Inner Layer Blocking.
 *
 * @author CS 18000 Project 05 Group Lab 12-3 Team 58
 * @version 12-10-2023
 */
public class Blocking {
    public int returnBlockingStatus(Conversation conversation) {
        conversation.fillNamesList("Data/LogFileNames.txt");
        //returns the blocking status on your log
        ArrayList<String> logFileNames = conversation.getLogFileNames();
        int i = -1;
        do {
            i++;
        } while (!(logFileNames.get(i).contains(conversation.fileName(1))));
        return Integer.parseInt(logFileNames.get(i).substring(logFileNames.get(i).length() - 1));

    }

    //contains methods which deal with blocking.
    public void setFlag(Conversation conversation, boolean blocking) {
        //blocking = true? -> we are doing blocking
        //blocking = false? -> we are doing unblocking
        String a = conversation.getSender();
        String b = conversation.getReceiver();

        String aTob = conversation.fileName(1) + ".txt";
        String bToa = conversation.fileName(2) + ".txt";

        ///find the convesation in the log files

        ArrayList<String> currentLogFileNames = conversation.getLogFileNames();


        int i = 0;
        //loop until we find first instance of a,b or b,a
        //get the index and whether its a,b or b,a at index
        //we then know index + 1 is the opposite of that
        while (!(currentLogFileNames.get(i).contains(aTob)) && !(currentLogFileNames.get(i).contains(bToa))) {
            i++;
        }
        int indexA = 0;
        int indexB = 0;
        if (currentLogFileNames.get(i).contains(aTob)) {
            indexA = i;
            indexB = i + 1;
            //its a to b
            // next it b to a

        } else {
            indexA = i + 1;
            indexB = i;
            //b to a
            //next is a to b
        }


        //selection time
        int aFlag =
                Integer.parseInt(currentLogFileNames.get(indexA).
                        substring(currentLogFileNames.get(i).length() - 1));
        int bFlag = Integer.parseInt(currentLogFileNames.get(indexB).
                substring(currentLogFileNames.get(indexB).length() - 1));

//defualt both open
        if (blocking) {
            if (aFlag == 0 && bFlag == 0) {
                //one blocked one open
                currentLogFileNames.set(indexA, aTob + ";1");
                currentLogFileNames.set(indexB, bToa + ";2");
            } else if (aFlag == 2) {
                //both blocked
                currentLogFileNames.set(indexA, aTob + ";3");
                currentLogFileNames.set(indexB, bToa + ";3");
            }
        } else {
            if (bFlag == 2) {
                //only one block, which i am undoing
                currentLogFileNames.set(indexA, aTob + ";0");
                currentLogFileNames.set(indexB, bToa + ";0");
            } else if (bFlag == 3) {
                //both blocked, undoing mine
                currentLogFileNames.set(indexA, aTob + ";2");
                currentLogFileNames.set(indexB, bToa + ";1");
            }
        }
        //clear
        PrintWriter clear = null;
        try {
            clear = new PrintWriter(new FileWriter("Data/LogFileNames.txt"));
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }
        clear.println();
        clear.close();
//rewrite
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream("Data/LogFileNames.txt");
            PrintWriter pw = new PrintWriter(fos);
            for (int j = 0; j < currentLogFileNames.size(); j++) {
                pw.println(currentLogFileNames.get(j));
            }
            pw.close();
        } catch (FileNotFoundException e) {
        }

    }


}
