import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 * Page.java
 * <p>
 * This is a helper GUI class.
 *
 * @author CS 18000 Project 05 Group Lab 12-3 Team 58
 * @version 12-10-2023
 */
public class Page extends JPanel {
    Random random = new Random();
    String name;

    public Page(String name) {
        this.name = name;
        this.setPreferredSize(new Dimension(300, 300));
        this.setBackground(new Color(random.nextInt()));
    }
}
