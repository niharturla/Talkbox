import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Logging.java
 *
 * This class houses methods to help Server read and write to Users.json.
 *
 * @author CS 18000 Project 05 Group Lab 12-3 Team 58
 * @version 12-10-2023
 */
public class Logging {

    public synchronized CopyOnWriteArrayList<User> readJSON(String filename) {
        CopyOnWriteArrayList<User> users = new CopyOnWriteArrayList<>();
        try {
            File log = new File(filename);
            if (log.length() != 0) {
                ObjectMapper mapper = new ObjectMapper();
                ArrayList<User> userArr =(ArrayList<User>) mapper.readValue(log, new TypeReference<List<User>>(){});

                for(User u : userArr) {
                    users.add(u);
                }
            } else {
                users = new CopyOnWriteArrayList<>();
            }
        } catch (JsonProcessingException e) {
        } catch (IOException e) {
        }
        return users;

    }

    public synchronized void writeJSON(CopyOnWriteArrayList<User> users, String filename) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(filename), users);
        } catch (IOException e) {
        }

    }

    public ArrayList<String> readChatLog(String self, String target) throws IOException {
        //Will find the chat log that needs to be read
        BufferedReader bfr = new BufferedReader(new FileReader("Data/Convos/" + self + "," + target + ".txt"));

        ArrayList<String> chat = new ArrayList<>(); //Will store the chat log ArrayList to return

        String l; //Stores the line being read
        while ((l = bfr.readLine()) != null) {
            chat.add(l);
        }
        return chat;
    }

}
