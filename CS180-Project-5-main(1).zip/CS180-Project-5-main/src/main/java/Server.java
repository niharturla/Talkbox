import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Server.java
 * <p>
 * Server.java does all the computation for the application. For every new Client that connects to Server a new
 * userThread is created.
 *
 * @author CS 18000 Project 05 Group Lab 12-3 Team 58
 * @version 12-10-2023
 */
class userThread extends Thread {
    private Socket socket;

    private PrintWriter out;
    private BufferedReader in;

    private ObjectInputStream objectIn;
    private ObjectOutputStream objectOut;
    private static CopyOnWriteArrayList<User> users;
    private User self;

    private Conversation conversation;

    public userThread(Socket socket) {
        this.socket = socket;
    }


    @Override
    public void run() {
        try {
            objectOut = new ObjectOutputStream(socket.getOutputStream());
            objectIn = new ObjectInputStream(socket.getInputStream());

            //Establishes communication with the client
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out = new PrintWriter(socket.getOutputStream(), true); //Speaks to client

            String command;

            Logging logging = new Logging();
            while (socket.isConnected()) {

                users = logging.readJSON("Data/Users.json"); //gets most recent list of users

                command = in.readLine();

                if (command == null || command.equals("")) {
                    //NOTHING HERE JUST MOVE ON.
                    continue;
                } else if (command.equals("refresh")) {
                    refresh(out);
                    out.println("Refreshed");

                } else if (command.equals("firstRefresh")) {
                    firstRefresh(out);
                    out.println("Refreshed");
                } else if (command.split("--")[0].equals("Login")) {
                    //"Login");
                    String[] commandSplit = command.split("--");
                    String username = commandSplit[1];
                    String pass = commandSplit[2];

                    boolean found = false;
                    for (int i = 0; i < users.size(); i++) {
                        if (users.get(i).getUsername().equals(username) && users.get(i).getPassword().equals(pass)) {
                            self = users.get(i);
                            found = true;
                        }
                    }

                    if (found) {
                        out.println("Success");
                        //"Success");

                        objectOut.writeObject(self);
                        objectOut.flush();
                        //self.getUsername() + " has logged in!");


                    } else {
                        out.println("Failed");
                        //"Failed");

                    }
                } else if (command.split("--")[0].equals("Signup")) {

                    //validate that this doesnt alr exist.
                    String[] commandSplit = command.split("--");
                    String username = commandSplit[1];
                    String password = commandSplit[2];
                    String role = commandSplit[3];

                    boolean exists = !validateName(username);

                    if (exists) {
                        //tell the client that is alr exists
                        out.println("Already Exists");
                    } else {
                        out.println("Unique");
                        //"Unique");
                        self = new User(role, username, password, false);
                        //add this user to the json!
                        users.add(self);
                        //users);

                    }
                } else if (command.split("--")[0].equals("reloadChatLog")) {
                    //Sends the newest chats to client
                    String[] commandSplit = command.split("--");
                    //Splits the command into its useful components
                    //Will be used to check if a conversation exists and if it does not create one
                    conversation = new Conversation(commandSplit[1], commandSplit[2]);
                    conversation.fillNamesList("Data/LogFileNames.txt");
                    if (!conversation.checkConvoPairExists()) {
                        conversation.createNewConvoPair();
                    }
                    reloadChatLog(commandSplit[1], commandSplit[2], out);//Executes the command

                } else if (command.split("--")[0].equals("addMessage")) {
                    //Adds a message to the conversation
                    String[] commandSplit = command.split("--", 4);
                    //Splits command into its useful components

                    //Creates a conversation object and calls its addMessage method
                    conversation.fillNamesList("Data/LogFileNames.txt");
                    conversation.addMessage(commandSplit[3]);

                } else if (command.split("--")[0].equals("deleteMessage")) {
                    //Removes message in the conversation
                    String[] commandSplit = command.split("--", 4);
                    //Splits command into its useful components
                    //Creates a conversation object and calls its deleteMessage method
                    conversation.fillNamesList("Data/LogFileNames.txt");
                    //make sure that deletiong is only happening to selfs lines.


                    if (conversation.deleteMessage(Integer.parseInt(commandSplit[3]))) {
                        out.println("Deleted");
                    } else {
                        out.println("IllegalDeletion");
                    }

                } else if (command.split("--")[0].equals("modifyMessage")) {
                    //Modifies a message in the conversation
                    String[] commandSplit = command.split("--", 5);
                    //Splits the command into its useful components

                    //Creates a conversation object and calls its editMessage method
                    conversation.fillNamesList("Data/LogFileNames.txt");

                    if (conversation.editMessage(Integer.parseInt(commandSplit[3]), commandSplit[4])) {
                        out.println("Edited");
                    } else {
                        out.println("IllegalEdit");
                    }

                } else if (command.split("--")[0].equals("addStore")) {
                    //Adds a store to the current user "self"
                    //command);
                    String[] commandSplit = command.split("--");
                    //Splits the command into its useful components

                    //Validates the store name (Checks if unique)
                    if (validateName(commandSplit[1])) {
                        self.addStore(commandSplit[1]);

                        //self.getStores());

                        synchronized (Server.loggingKey) {
                            logging.writeJSON(users, "Data/Users.json");
                        }
                        out.println("Added Successfully");
                    } else {
                        out.println("Failed Not Unique");
                    }

                } else if (command.split("--")[0].equals("removeStore")) { //Removes a store from the user "self"
                    String[] commandSplit = command.split("--"); //Splits command into its useful components

                    String toBeRemoved = commandSplit[1]; //Stores the name of the store to be removed (if it exists)

                    //Iterate over the current user "self"'s stores
                    boolean deleted = false;
                    for (String store : self.getStores()) {
                        if (store.equals(toBeRemoved)) { //if the store is found, delete it
                            self.removeStore(toBeRemoved);
                            deleted = true;
                            break;
                        }
                    }

                    if (deleted) {
                        synchronized (Server.loggingKey) {
                            logging.writeJSON(users, "Data/Users.json");
                        }
                        out.println("Deleted Successfully");
                    } else {
                        out.println("Failed Nonexistent");
                    }
                } else if (command.split("--")[0].equals("invis")) { //Will make themselves invisible to the
                    // target user

                    String[] commandSplit = command.split("--"); //Splits command into its useful components

                    //iterate over all users to find the target
                    for (User u : users) {
                        if (u.getUsername().equals(commandSplit[1])) { //If the user's username equals the target, add
                            //them to the hit-list
                            self.addInvisibleHitlist(u.getUsername());
                            break;
                        }
                    }

                    out.println("Successfully Invised");
                } else if (command.split("--")[0].equals("unInvis")) { //Will remove the user from the hit-list
                    String[] commandSplit = command.split("--"); //Splits the command into it's useful components

                    //Iterate over all users to find the target
                    for (User u : users) {
                        if (u.getUsername().equals(commandSplit[1])) { //If the user's username equals the target,
                            //remove them from the hit-list
                            self.removeInvisibleHitlist(u.getUsername());
                        }
                    }

                    out.println("Successfully unInvised");
                } else if (command.split("--")[0].equals("blockUser")) {
                    String[] commandSplit = command.split("--"); //Splits command into its useful components

                    //iterate over all users to find the target
                    for (User u : users) {
                        if (u.getUsername().equals(commandSplit[1])) { //If the user's username equals the target, add
                            //them to the block list
                            self.addToBlockList(u.getUsername());
                            break;
                        }
                    }
                    out.println("Successfully Blocked User");
                } else if (command.split("--")[0].equals("unblockUser")) {
                    String[] commandSplit = command.split("--"); //Splits command into its useful components

                    //iterate over all users to find the target
                    for (User u : users) {
                        if (u.getUsername().equals(commandSplit[1])) { //If the user's username equals the target, add
                            //them to the block list
                            self.removeFromBlockList(u.getUsername());
                            break;
                        }
                    }
                    out.println("Successfully Unblocked User");
                } else if (command.split("--")[0].equals("checkUserBlockStatus")) {
                    //checkUserBlockStatus--[target]
                    String[] commandSplit = command.split("--");

                    String target = commandSplit[1]; //gets the target

                    //Iterate through the target's entire blocked list to see if the target is a blocked user
                    //or the store of a blocked user
                    boolean blocked = false; //will be set to true if the user is blocked

                    //Find the user "target" and check to see if self is in its blocked list
                    for (User u : users) {
                        if (u.getUsername().equals(target)) {
                            if (u.getBlockingList().contains(self.getUsername())) {
                                blocked = true;
                            }
                            break;
                        }
                    }

                    if (blocked) {
                        out.println("User Blocked");
                    } else {
                        out.println("User Not Blocked");
                    }
                } else if (command.split("--")[0].equals("talkedTo")) {
                    String[] commandSplit = command.split("--"); //Splits command into useful components

                    //Instantiating an ArrayList that will hold the names of all the buyers that the store has talked to
                    ArrayList<String> talkedTo = new ArrayList<>();

                    //Create a BufferedReader to read through all the names of the log files
                    BufferedReader bfr = new BufferedReader(new FileReader("Data/LogFileNames.txt"));

                    String l; //Will hold the line currently being read
                    while ((l = bfr.readLine()) != null) { //Iterate through all the lines of LogFileNames.txt
                        //Add the buyer to the list if the store has a conversation log with them
                        if (l.split(";")[0].split(",")[0].equals(commandSplit[1])) {
                            talkedTo.add(l.split(";")[0].split(",")[1].split("\\.")[0]);
                        }
                    }

                    //Send the ArrayList over once done
                    objectOut.writeObject(talkedTo);
                    objectOut.flush();
                    out.println("talkedTo Success");

                } else if (command.split("--")[0].equals("export")) {
                    String[] commandSplit = command.split("--"); //Splits the command into it's useful components

                    //Read over the chatLog to send as an ArrayList and turn into a csv on the client
                    BufferedReader bfr = new BufferedReader(new FileReader("Data/Convos/" + commandSplit[1] +
                            "," + commandSplit[2] + ".txt")); //Reader for the chat log

                    ArrayList<String> chat = new ArrayList<>(); //ArrayList to send
                    String l; //Will hold the current line being read
                    while ((l = bfr.readLine()) != null) {
                        String[] lineList = new String[5];


                        //Line will look like this:
                        //5;07-11-2023 12:05:52;[Nihar1] - How, are you doing?;8
                        //Add the 4 parts of line to lineList array. Add commas to all but index 3.

                        //Line Number
                        lineList[0] = l.split(";")[l.split(";").length - 1] + ",";

                        //Skips over if the line is deleted
                        if (lineList[0].equals("D,")) {
                            continue;
                        }

                        //Date
                        lineList[1] = l.split(";")[1].split(" ")[0] + ",";


                        //Time
                        lineList[2] = l.split(";")[1].split(" ")[1] + ",";

                        //Name
                        lineList[3] = l.split(";")[2].split(" - ")[0] + ",";

                        //Message
                        String msgPartUncut = l.split(" - ")[1];
                        lineList[4] = msgPartUncut.substring(0, msgPartUncut.lastIndexOf(';'));

                        chat.add(lineList[0] + lineList[1] + lineList[2] + lineList[3] + lineList[4]);

                    }

                    //Send the object and confirmation over to the client
                    objectOut.writeObject(chat);
                    out.println("ArrayList Sent");
                    objectOut.flush();
                } else if (command.split("--")[0].equals("updateBlocking")) {
                    String[] commandSplit = command.split("--"); //Splits the command into it's useful components
                    conversation.fillNamesList("Data/LogFileNames.txt");
                    Blocking block = new Blocking();
                    int selfStatus = block.returnBlockingStatus(conversation);
                    out.println(selfStatus);
                } else if (command.split("--")[0].equals("blocking")) {
                    String[] commandSplit = command.split("--"); //Splits the command into it's useful components
                    conversation.fillNamesList("Data/LogFileNames.txt");
                    Blocking blocking = new Blocking();
                    if (commandSplit[3].equals("1")) {
                        blocking.setFlag(conversation, true);
                        out.println("B");
                    } else {
                        blocking.setFlag(conversation, false);
                        out.println("UB");
                    }

                } else if (command.equals("logout")) {
                    //we are going to close the thread which requested to logout
                    self = null;
                    firstRefresh(out);
                } else if (command.split("--")[0].equals("setCurrentStore")) {
                    String[] commandSplit = command.split("--");

                    self.setCurrentStore(commandSplit[1]);
                    updateSelfInList();
                    synchronized (Server.loggingKey) {
                        logging.writeJSON(users, "Data/Users.json");
                    }
                    out.println("Set Current Store");
                }

                //Updates the instance of self in the ArrayList if self is NOT null
                if (self != null) {
                    updateSelfInList();
                }
                synchronized (Server.loggingKey) {
                    logging.writeJSON(users, "Data/Users.json"); //rewrite users ArrayList in the JSON
                }

            }
        } catch (Exception e) {
            //"Client disconnected");
        }
    }

    //Gathers the new information and logs and sends them back
    public void refresh(PrintWriter out) throws IOException, ClassNotFoundException {
        //Reads Users.json to get an ArrayList of all the users


        Logging reader = new Logging();
        CopyOnWriteArrayList<User> users = reader.readJSON("Data/Users.json");

        //Sends the user objects over
        objectOut.writeObject(users);
        objectOut.flush();
        //users);

        //self.getCurrentStore());
        objectOut.writeObject(self);
        //"writtin self");
        objectOut.flush();
        //"Flushed");
    }

    //Gathers the new information and logs and sends them back
    public void firstRefresh(PrintWriter out) throws IOException, ClassNotFoundException {
        //Reads Users.json to get an ArrayList of all the users
        Logging reader = new Logging();
        CopyOnWriteArrayList<User> users = reader.readJSON("Data/Users.json");

        //Sends the user objects over
        objectOut.writeObject(users);
        objectOut.flush();
        //users);
    }

    //Sends the updated chat log
    public synchronized void reloadChatLog(String self, String target, PrintWriter out) throws IOException {
        //Creating a Logging object and calling its readChatLog function to get the raw current chat into an ArrayList
        ArrayList<String> chat = new ArrayList<>();
        synchronized (Server.loggingKey) {
            Logging logging = new Logging();
            chat = logging.readChatLog(self, target);
        }

        //Iterates over the ArrayList, reformats the strings to HTML, and adds them to the String chatLog in HTML format
        String chatLog = "<html><p>";
        for (int i = 0; i < chat.size(); i++) {
            String s = chat.get(i); //Get the current line of the chat log that's being read

            String[] splitString = s.split(";", 3);//Splits the string into useful components

            //Gets the "display line" or the deletion flag from the line
            String displayLine = splitString[2].substring(splitString[2].lastIndexOf(";") + 1,
                    splitString[2].length());

            if (displayLine.equals("D")) { //Skip over this line if it has been deleted by the user
                continue;
            }

            //Will format the line differently depending on if this line is the last line in the chat, which would need
            //to not have a new line indication
            String formattedLine; //Stores the HTML formatted line
            if (i < chat.size() - 1) {
                //Create the HTML formatted line with a line break and add it to chatLog
                formattedLine = "<b>" + displayLine + ": </b>" + splitString[1] + " - " +
                        splitString[2].substring(0, splitString[2].lastIndexOf(";")) + "<br/>";
            } else {
                //Create the HTML formatted line without a line break and add it to chatLog
                formattedLine = "<b>" + displayLine + ": </b>" + splitString[1] + " - " +
                        splitString[2].substring(0, splitString[2].lastIndexOf(";"));
            }

            chatLog += formattedLine; //Add the line to the HTMl string
        }
        chatLog += "</p></html>"; //Finalize the HTML formatting

        out.println(chatLog); //Send the updated chat log over
        out.flush(); //Flush just in case
    }

    //Checks if the name is unique across both users and stores
    public synchronized boolean validateName(String name) {
        //Fixed issue with below
        //when we validate we want to make sure we are cross referencing the most updated users list
        Logging log = new Logging();
        users = log.readJSON("Data/Users.json");

        //iterate through every user
        for (User u : users) {
            if (u.getUsername().equals(name)) { //return false if name equals any of the users' usernames
                return false;
            }

            //Iterate through all the user's stores if the user is a seller
            if (u.getRole().equals("S")) {
                for (String store : u.getStores()) {
                    if (name.equals(store)) { //return false if any of the stores' names equals name
                        return false;
                    }
                }
            }
        }

        return true; //return true if this name passes all the checks
    }

    //Updates the instance of self in the ArrayList with the instance of self as a global field
    public synchronized void updateSelfInList() {

        //Iterate through the ArrayList of users
        for (int i = 0; i < users.size(); i++) {
            User u = users.get(i); //current user being checked
            if (u.getUsername().equals(self.getUsername())) {
                //If the user is an instance of self, update that instance
                users.set(i, self);
                //self);
                break;
            }
        }
    }

    //Export sender,receiver.txt as .csv file.
    public synchronized void exportCSV(String csvFileName) {
        try {
            FileReader fr = new FileReader(csvFileName.split(".")[0] + ".txt");
            BufferedReader br = new BufferedReader(fr);


            PrintWriter newThread = new PrintWriter(new FileWriter(csvFileName));


            String line = br.readLine();


            while (line != null) {
                String[] lineList = new String[5];


                //Line will look like this:
                //5;07-11-2023 12:05:52;[Nihar1] - How, are you doing?;8
                //Add the 4 parts of line to lineList array. Add commas to all but index 3.

                //Line Number
                lineList[0] = line.split(";")[line.split(";").length - 1] + ",";

                //Skips over if the line is deleted
                if (lineList.equals("D,")) {
                    continue;
                }

                //Date
                lineList[1] = line.split(";")[1].split(" ")[0] + ",";


                //Time
                lineList[2] = line.split(";")[1].split(" ")[1] + ",";

                //Name
                lineList[3] = line.split(";")[2].split(" - ")[0] + ",";

                //Message
                String msgPartUncut = line.split(" - ")[1];
                lineList[4] = msgPartUncut.substring(0, msgPartUncut.lastIndexOf(';'));

                //Format the original line to be .csv readable.
                String csvLine = lineList[0] + lineList[1] + lineList[2] + lineList[3] + lineList[4];
                //Write the csvLine into the csvFile.
                newThread.println(csvLine);

                line = br.readLine();
            }
            br.close();
            newThread.close();
            //"Export successful!");
        } catch (Exception e) {
        }
    }
}

public class Server {
    public static Object loggingKey = new Object();

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(80);

        //Checks for incoming clients and begins their thread
        while (true) {
            Socket socket = serverSocket.accept();
            new userThread(socket).start();
            //"New client connected");
        }
    }
}
