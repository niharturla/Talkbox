import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;

/**
 * Client.java
 * <p>
 * This class houses the entire GUI and deals with sending commands to Server.
 *
 * @author CS 18000 Project 05 Group Lab 12-3 Team 58
 * @version 12-10-2023
 */
public class Client extends JPanel implements Runnable {
    //CONSTANTS (PAGE KEYS)
    public final String CONNECTIVITY_PAGE = "Connectivity Page";
    public final String WELCOME_PAGE = "Welcome Page";
    public final String LOGIN_PAGE = "Login Page";
    public final String SIGN_UP_PAGE = "Sign-up Page";
    public final String FIRST_STORE_PAGE = "First Store Page";
    public final String CUSTOMER_PAGE = "Customer Page";
    public final String STORE_MANAGER_PAGE = "Store Manager Page";
    public final String SETTINGS_PAGE = "Settings Page";
    public final String SELLER_PAGE = "Seller Page";
    public final String SELECT_CUSTOMER_PAGE = "Select Customer Page";
    public final String SELECT_SELLER_PAGE = "Select Seller Page";
    public final String SELECT_STORE_PAGE = "Select Store Page";
    public final String CONVERSATION_MENU = "Conversation Menu";
    CardLayout cardLayout = new CardLayout();
    JPanel cards = new JPanel(cardLayout);
    private Client client;

    /*
    COMPONENTS ORDERED BY PAGE
     */

    //NAVIGATION (BUTTONS ONLY FOR TESTING/BUILDING)


    //Connectivity Page
    private JButton connectButton;
    private JTextField ipField;
    private PrintWriter out;
    private BufferedReader in;
    private ObjectInputStream objectIn;
    private ObjectOutputStream objectOut;
    private DataInputStream dataIn;
    private DataOutputStream dataOut;
    private Socket socket;
    private CopyOnWriteArrayList<User> users;
    private User self;
    private String currentChat;
    private boolean firstRefresh;
    private String target;

    //Connectivity page
    private JTextField portTextField;
    //Welcome Page
    JButton welcomePageLoginButton;
    JButton welcomePageSignupButton;

    //Login Page
    JTextField loginPageUsernameField;
    JTextField loginPagePasswordField;
    JButton loginPageLoginButton;
    JButton loginPageBackButton;

    //Sign-up Page
    JTextField signupPageUsernameField;
    JPasswordField signupPagePasswordField;
    JComboBox signupPageUserTypeDropdown;
    JTextField signupPageStoreField;
    JButton signupPageSignupButton;
    JButton signupPageBackButton;

    //First Store Page
    JTextField firstStoreText;
    JButton firstStoreButton;

    //Customer Page
    JButton messageStores;
    JButton customerSettings;
    JButton customerPageLogout;

    //Store Manager Page
    JTextField addStoreText;
    JButton addStoreButton;
    JTextField removeStoreText;
    JButton removeStoreButton;
    JButton storeManagerSelectStoreButton;
    JComboBox storeDropdownList;
    JButton logoutFromStoreManager;
    String[] stores = {};

    //Settings Page
    JComboBox selectInvisibleBox;
    JComboBox hitListBox;
    JButton becomeInvisible;
    JButton becomeVisible;
    JComboBox selectBlockBox;
    JComboBox blockedUserBox;
    ;
    JButton blockUser;
    JButton unblockUser;
    JButton returnToRolePage;
    JButton selectButton;

    //Seller Page
    JButton messageCustomers;
    JButton sellerPageSettingsButton;
    JButton sellerPageLogout;
    JButton returnToStoreManager;

    //Select Customer Page
    DefaultListModel customersAlreadyTalked;
    DefaultListModel customersNotTalked;
    JList customerList1; //alr talked
    JList customerList2; //not talked
    JButton selectCustomerPageSelectCustomerButtonOld;
    JButton selectCustomerPageSelectCustomerButtonNew;
    JButton selectCustomerBackButton;

    //Select Seller Page
    JComboBox selectSellerComboBox;
    JButton selectSellerButton;
    JButton selectSellerBackButton;

    //Select Store Page
    DefaultListModel storesAlreadyTalked;
    DefaultListModel storesNotTalked;
    JButton selectStorePageSelectStoreButtonOld;
    JButton selectStorePageSelectStoreButtonNew;
    JList storesList1; // already talked
    JList storesList2; // not talked
    JButton selectStoreBackButton;
    //Conversation Menu
    JLabel sendPanelPreviousConvo;
    JButton sendPanelSendButton;
    JTextField sendPanelTextfield;
    JScrollPane sendPanelScrollPane;
    JLabel deletePanelPreviousConvo;
    JButton deletePageButton;
    JTextField deletePageTextfield;
    JScrollPane deletePanelScrollPane;
    JLabel editPanelPreviousConvo;
    JTextField editPageNumberTextfield;
    JButton editPageButton;
    JTextField editPageMessageTextfield;
    JScrollPane editPanelScrollPane;
    JTextField importTextfield;
    JButton importButton;
    JButton exportButton;
    JLabel currentBlockStatus;
    JToggleButton blockButton;
    JLabel title;
    JButton conversationMenuBack;
    JTabbedPane tabbedPane;

    //MISC Components
    JTextField storeField;
    JFrame frame;

    public Client() {
        cards.add(buildConnectivityPage(), CONNECTIVITY_PAGE);
        cards.add(buildWelcomePage(), WELCOME_PAGE);
        cards.add(buildLoginPage(), LOGIN_PAGE);
        cards.add(buildSignupPage(), SIGN_UP_PAGE);
        cards.add(buildFirstStorePage(), FIRST_STORE_PAGE);
        cards.add(buildCustomerPage(), CUSTOMER_PAGE);
        cards.add(buildStoreManagerPage(), STORE_MANAGER_PAGE);
        cards.add(buildSettingsPage(), SETTINGS_PAGE);
        cards.add(buildSellerPage(), SELLER_PAGE);
        cards.add(buildSelectCustomerPage(), SELECT_CUSTOMER_PAGE);
        cards.add(buildSelectSellerPage(), SELECT_SELLER_PAGE);
        cards.add(buildSelectStorePage(), SELECT_STORE_PAGE);
        cards.add(buildConversationMenu(), CONVERSATION_MENU);
        setLayout(new BorderLayout());
        add(cards, BorderLayout.CENTER);
        firstRefresh = true;
    }

    ActionListener actionListener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == connectButton) {
                try {
                    //Establishes connection with the server
                    socket = new Socket(ipField.getText(), Integer.parseInt(portTextField.getText()));

                    //Establishes communication with the server
                    out = new PrintWriter(socket.getOutputStream(), true);
                    in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    objectIn = new ObjectInputStream(socket.getInputStream());
                    objectOut = new ObjectOutputStream(socket.getOutputStream());

                    firstRefresh(); //refreshes page

                    //"Connected to server!");
                    //Goes to the next page upon successful connection
                    CardLayout cl = (CardLayout) cards.getLayout();
                    cl.next(cards);
                } catch (IOException ex) {
                    //Catches when the socket can not connect
                    JOptionPane.showMessageDialog(cards, "Error! the ip/port is wrong",
                            "Error", JOptionPane.ERROR_MESSAGE);
                } catch (ClassNotFoundException cnfex) { //Catches when the refresh function malfunctions
                    JOptionPane.showMessageDialog(cards, "Error! could not receive information properly from" +
                            "the server", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) { //Catches when the socket can not connect
                    JOptionPane.showMessageDialog(cards, "Error! the ip/port is wrong",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }

            if (e.getSource() == welcomePageLoginButton) {
                changePage(LOGIN_PAGE);
            }
            if (e.getSource() == welcomePageSignupButton) {
                changePage(SIGN_UP_PAGE);
            }
            if (e.getSource() == loginPageLoginButton) {
                login();
            }
            if (e.getSource() == loginPageBackButton) {
                changePage(WELCOME_PAGE);
            }
            if (e.getSource() == signupPageSignupButton) {
                signup();
            }
            if (e.getSource() == signupPageBackButton) {
                changePage(WELCOME_PAGE);
            }
            if (e.getSource() == firstStoreButton) {
                firstStore();
            }
            if (e.getSource() == customerSettings) {
                try {
                    refresh();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
                settingsInvisibility();
                settingsBlocking();
                changePage(SETTINGS_PAGE);
            }
            if (e.getSource() == customerPageLogout) {
                logout();
                //Must wipe everything clean
                changePage(WELCOME_PAGE);
            }
            if (e.getSource() == messageStores) {
                //we need to update the dropdown of sellers.
                try {
                    refresh();
                    //users);
                    //"HERE");
                    selectSellerComboBox.removeAllItems();
                    for (int i = 0; i < users.size(); i++) {
                        if (users.get(i).getRole().equals("S") &&
                                !users.get(i).getInvisibleHitlist().contains(self.getUsername())) {
                            selectSellerComboBox.addItem(users.get(i).getUsername());
                        }
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
                changePage(SELECT_SELLER_PAGE);
                //"Got here");
            }
            if (e.getSource() == addStoreButton) {
                storeManager(1);
            }
            if (e.getSource() == removeStoreButton) {
                storeManager(2);
            }
            if (e.getSource() == storeManagerSelectStoreButton) {
                storeManager(3);
            }
            if (e.getSource() == logoutFromStoreManager) {
                logout();
                //must wipe everything clean
                changePage(WELCOME_PAGE);
            }
            if (e.getSource() == returnToRolePage) {
                if (self.getRole().equals("S")) {
                    changePage(SELLER_PAGE);
                } else if (self.getRole().equals("C")) {
                    changePage(CUSTOMER_PAGE);
                }
                // seller -> seller Page
                // customer -> customer Page
            }

            if (e.getSource() == selectButton) {
                // after the user selects
                try {
                    String selectedHit = (String) hitListBox.getSelectedItem();
                    out.println("invis--[" + selectedHit + ".]");
                    if (in.readLine().equals("Successfully invised")) {
                        refresh();
                    }
                } catch (Exception err) {
                    JOptionPane.showMessageDialog(null, "ERROR", "select",
                            JOptionPane.ERROR_MESSAGE);
                }
            }

            if (e.getSource() == messageCustomers) {
                selectCustomer();
            }
            if (e.getSource() == sellerPageSettingsButton) {
                try {
                    refresh();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
                settingsInvisibility();
                settingsBlocking();
                changePage(SETTINGS_PAGE);

            }
            if (e.getSource() == sellerPageLogout) {
                logout();
                //must wipe everything clean
                changePage(WELCOME_PAGE);
            }
            if (e.getSource() == returnToStoreManager) {
                changePage(STORE_MANAGER_PAGE);
            }
            if (e.getSource() == selectCustomerPageSelectCustomerButtonOld) {
                if (customerList1.getSelectedValue() != null) {
                    target = (String) customerList1.getSelectedValue();

                    out.println("checkUserBlockStatus--" + target); //Checks if we are blocked
                    try {
                        if (in.readLine().equals("User Not Blocked")) {
                            //target);
                            title.setText("You are messaging: " + target);
                            User targetCustomer = new User();
                            for (int i = 0; i < users.size(); i++) {
                                if (users.get(i).getUsername().equals(target)) {
                                    targetCustomer = users.get(i);
                                    break;
                                }
                            }
                            try {
                                reloadChatLog(targetCustomer);
                                updateBlocking(targetCustomer.getUsername());
                            } catch (IOException ex) {
                                JOptionPane.showMessageDialog(null, "Error!", "Error",
                                        JOptionPane.ERROR_MESSAGE);
                            } catch (ClassNotFoundException ex) {
                                JOptionPane.showMessageDialog(null, "Error!", "Error",
                                        JOptionPane.ERROR_MESSAGE);
                            }
                            sendPanelPreviousConvo.setText(currentChat);
                            deletePanelPreviousConvo.setText(currentChat);
                            editPanelPreviousConvo.setText(currentChat);
                            changePage(CONVERSATION_MENU);
                        } else {
                            JOptionPane.showMessageDialog(null, "Error! This user has" +
                                            " blocked " + "you! You will not be able to message them until they " +
                                            "unblock you", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception exception) {

                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You must select a customer!",
                            "Error", JOptionPane.ERROR_MESSAGE);

                }
            }
            if (e.getSource() == selectCustomerPageSelectCustomerButtonNew) {
                if (customerList2.getSelectedValue() != null) {
                    try {
                        target = (String) customerList2.getSelectedValue();

                        //Checking if the user blocked us
                        out.println("checkUserBlockStatus--" + target);
                        if (in.readLine().equals("User Not Blocked")) {
                            title.setText("You are messaging: " + target);
                            User targetCustomer = null;
                            for (int i = 0; i < users.size(); i++) {
                                if (users.get(i).getUsername().equals(target)) {
                                    targetCustomer = users.get(i);
                                    break;
                                }
                            }
                            try {
                                reloadChatLog(targetCustomer);
                                updateBlocking(targetCustomer.getUsername());
                            } catch (IOException ex) {
                                JOptionPane.showMessageDialog(null, "Error!",
                                        "Error", JOptionPane.ERROR_MESSAGE);
                            } catch (ClassNotFoundException ex) {
                                JOptionPane.showMessageDialog(null, "Error!",
                                        "Error", JOptionPane.ERROR_MESSAGE);
                            }
                            sendPanelPreviousConvo.setText(currentChat);
                            deletePanelPreviousConvo.setText(currentChat);
                            editPanelPreviousConvo.setText(currentChat);
                            changePage(CONVERSATION_MENU);
                            //"fjfj");
                        } else {
                            JOptionPane.showMessageDialog(null, "Error! This user has blocked "
                                            + "you! You will not be able to message them until they unblock you",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception exception) {

                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You must select a customer!",
                            "Error", JOptionPane.ERROR_MESSAGE);

                }
            }
            if (e.getSource() == selectCustomerBackButton) {
                changePage(SELLER_PAGE);
            }
            if (e.getSource() == selectSellerButton) {
                String seller = (String) selectSellerComboBox.getSelectedItem();
                out.println("checkUserBlockStatus--" + seller);
                try {
                    if (in.readLine().equals("User Not Blocked")) {
                        updateTargetSellersStores();
                    } else {
                        JOptionPane.showMessageDialog(null, "Error! This user has blocked " +
                                        "you! You will not be able to message them until they unblock you",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception exception) {
                }
            }
            if (e.getSource() == selectSellerBackButton) {
                changePage(CUSTOMER_PAGE);
            }
            if (e.getSource() == selectStorePageSelectStoreButtonOld) {
                if (storesList1.getSelectedValue() != null) {
                    target = (String) storesList1.getSelectedValue();
                    //target);
                    title.setText("You are messaging: " + target);
                    try {
                        reloadChatLog(target);
                        updateBlocking(target);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    sendPanelPreviousConvo.setText(currentChat);
                    deletePanelPreviousConvo.setText(currentChat);
                    editPanelPreviousConvo.setText(currentChat);
                    changePage(CONVERSATION_MENU);
                } else {
                    JOptionPane.showMessageDialog(null, "You must select a store!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            if (e.getSource() == selectStorePageSelectStoreButtonNew) {
                if (storesList2.getSelectedValue() != null) {
                    target = (String) storesList2.getSelectedValue();
                    //target);
                    title.setText("You are messaging: " + target);
                    //create a new convo pair

                    try {
                        reloadChatLog(target);
                        updateBlocking(target);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    sendPanelPreviousConvo.setText(currentChat);
                    deletePanelPreviousConvo.setText(currentChat);
                    editPanelPreviousConvo.setText(currentChat);
                    changePage(CONVERSATION_MENU);
                } else {
                    JOptionPane.showMessageDialog(null, "You must select a store!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            if (e.getSource() == selectStoreBackButton) {
                changePage(SELECT_SELLER_PAGE);
            }
            if (e.getSource() == sendPanelSendButton) {
                if (!sendPanelTextfield.getText().isBlank()) {
                    try {
                        //dummy user
                        User user = new User(" ", target, " ", false);
                        //store and cus is string user
                        // cus and store string, string
                        if (self.getRole().equals("C")) {
                            sendMessage(sendPanelTextfield.getText(), target);
                            reloadChatLog(target);
                        } else {

                            sendMessage(sendPanelTextfield.getText(), user);
                            reloadChatLog(user);
                        }


                        refresh();
                        sendPanelPreviousConvo.setText(currentChat);
                        //update delete and edit previous convo
                        editPanelPreviousConvo.setText(currentChat);
                        deletePanelPreviousConvo.setText(currentChat);
                        sendPanelScrollPane.revalidate();
                        int max = sendPanelScrollPane.getVerticalScrollBar().getMaximum();
                        sendPanelScrollPane.getVerticalScrollBar().setValue(max);

                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You must enter a message!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }


            }
            if (e.getSource() == deletePageButton) {
                try {
                    if (deletePageTextfield.getText().isBlank()) {

                        JOptionPane.showMessageDialog(null, "You must enter a line number!",
                                "Error", JOptionPane.ERROR_MESSAGE);

                    } else if (Integer.parseInt(deletePageTextfield.getText()) < 0) {
                        JOptionPane.showMessageDialog(null, "You cannot enter a line" +
                                " number less than 0!", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        //store and cus is sstring user
                        // cus and store string, string
                        if (self.getRole().equals("C")) {
                            deleteMessage(deletePageTextfield.getText(), target);
                        } else {
                            User targetUser = null;
                            for (User u : users) {
                                if (u.getUsername().equals(target)) {
                                    targetUser = u;
                                    break;
                                }
                            }
                            deleteMessage(deletePageTextfield.getText(), targetUser);
                        }
                    }
                } catch (NumberFormatException nfe) {
                    JOptionPane.showMessageDialog(null, "You did not enter a integer to" +
                                    " the line number field. You must enter a number construed with characters " +
                                    "0-9", "Number Format Error",
                            JOptionPane.ERROR_MESSAGE);

                }
            }
            if (e.getSource() == editPageButton) {
                if (!editPageMessageTextfield.getText().isBlank() && !editPageNumberTextfield.getText().isBlank()) {
                    try {
                        //dummy user
                        User user = new User(" ", target, " ", false);
                        //store and cus is sstring user
                        // cus and store string, string
                        if (Integer.parseInt(editPageNumberTextfield.getText()) < 0) {
                            JOptionPane.showMessageDialog(null, "You cannot enter a line" +
                                    " number less than 0!", "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            if (self.getRole().equals("C")) {
                                String number = editPageNumberTextfield.getText();
                                modifyMessage(number, target, editPageMessageTextfield.getText());
                            } else {
                                String number = editPageNumberTextfield.getText();
                                modifyMessage(number, user, editPageMessageTextfield.getText());

                            }
                            String reply = in.readLine();

                            if (reply.equals("IllegalEdit")) {
                                JOptionPane.showMessageDialog(null, "You cannot edit" +
                                                " a message that you did not send!", "Error",
                                        JOptionPane.ERROR_MESSAGE);
                            } else if (reply.equals("Edited")) {
                                if (self.getRole().equals("C")) {
                                    reloadChatLog(target);
                                } else {
                                    reloadChatLog(user);
                                }

                                refresh();
                                editPanelPreviousConvo.setText(currentChat);
                                //update send and delete
                                sendPanelPreviousConvo.setText(currentChat);
                                deletePanelPreviousConvo.setText(currentChat);
                                editPanelScrollPane.revalidate();
                            }
                        }
                    } catch (NumberFormatException nfe) {
                        JOptionPane.showMessageDialog(null, "You did not enter a integer to" +
                                        " the line number field. You must enter a number construed with characters " +
                                        "0-9", "Number Format Error",
                                JOptionPane.ERROR_MESSAGE);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You must enter a line number an" +
                                    "d a message!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
            if (e.getSource() == importButton) {
                importButtonActionPerformed(e);
                tabbedPane.setSelectedIndex(0);
            }

            if (e.getSource() == blockButton) {
                if (blockButton.isSelected()) {
                    //block
                    block(target, 1);

                } else {
                    //un
                    block(target, 2);

                }
            }

            if (e.getSource() == conversationMenuBack) {
                if (self.getRole().equals("S")) {
                    changePage(SELECT_CUSTOMER_PAGE);
                } else if (self.getRole().equals("C")) {
                    changePage(SELECT_STORE_PAGE);
                }
            }

            if (e.getSource() == exportButton) {
                try {
                    if (self.getRole().equals("S")) {
                        out.println("export--" + self.getCurrentStore() + "--" + target);
                    } else if (self.getRole().equals("C")) {
                        out.println("export--" + self.getUsername() + "--" + target);
                    }

                    ArrayList<String> exportChat = (ArrayList<String>) objectIn.readObject();
                    if (in.readLine().equals("ArrayList Sent")) {
                        exportCSV(exportChat);
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }

            if (e.getSource() == becomeInvisible) {
                try {
                    if (selectInvisibleBox.getSelectedItem() == null) {
                        invalidInputError();
                    } else {
                        out.println("invis--" + selectInvisibleBox.getSelectedItem());

                        if (in.readLine().equals("Successfully Invised")) {
                            JOptionPane.showMessageDialog(frame, "Successfully became invisible to "
                                    + selectInvisibleBox.getSelectedItem() + "!");
                            self.addInvisibleHitlist((String) selectInvisibleBox.getSelectedItem());
                        }

                        refresh();
                        settingsInvisibility();
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(frame, "Sorry! That action could not be performed!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    try {
                        refresh();
                    } catch (IOException exc) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    } catch (ClassNotFoundException exc) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    settingsInvisibility();

                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }

            if (e.getSource() == becomeVisible) {
                try {
                    if (hitListBox.getSelectedItem() == null) {
                        invalidInputError();
                    } else {
                        out.println("unInvis--" + hitListBox.getSelectedItem());
                        if (in.readLine().equals("Successfully unInvised")) {
                            JOptionPane.showMessageDialog(frame, "Successfully became visible to "
                                    + hitListBox.getSelectedItem() + "!");
                            self.removeInvisibleHitlist((String) hitListBox.getSelectedItem());
                        }

                        refresh();
                        settingsInvisibility();
                        //self.getInvisibleHitlist();
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(frame, "Sorry! That action could not be performed!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    try {
                        refresh();
                    } catch (IOException exc) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    } catch (ClassNotFoundException exc) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    settingsInvisibility();
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
            if (e.getSource() == blockUser) {
                if (selectBlockBox.getSelectedItem() == null) {
                    invalidInputError();
                } else {
                    try {
                        out.println("blockUser--" + selectBlockBox.getSelectedItem());
                        String reply = in.readLine();
                        if (reply.equals("Successfully Blocked User")) {
                            JOptionPane.showMessageDialog(null, "Successfully blocked "
                                            + selectBlockBox.getSelectedItem() + "!", "Success!",
                                    JOptionPane.INFORMATION_MESSAGE);
                            self.addToBlockList((String) selectBlockBox.getSelectedItem());
                        }
                        refresh();
                        settingsBlocking();
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(frame, "Sorry! That action could not be performed!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        try {
                            refresh();
                        } catch (IOException exc) {
                            JOptionPane.showMessageDialog(null, "Error!", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        } catch (ClassNotFoundException exc) {
                            JOptionPane.showMessageDialog(null, "Error!", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                        settingsBlocking();
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }

            }
            if (e.getSource() == unblockUser) {
                if (blockedUserBox.getSelectedItem() == null) {
                    invalidInputError();
                } else {
                    try {
                        out.println("unblockUser--" + blockedUserBox.getSelectedItem());
                        String reply = in.readLine();
                        if (reply.equals("Successfully Unblocked User")) {
                            JOptionPane.showMessageDialog(frame, "Successfully unblocked to "
                                    + blockedUserBox.getSelectedItem() + "!");
                            self.removeFromBlockList((String) blockedUserBox.getSelectedItem());
                        }

                        refresh();
                        settingsBlocking();
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(frame, "Sorry! That action could not be performed!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        try {
                            refresh();
                            settingsBlocking();
                        } catch (Exception exception) {
                            JOptionPane.showMessageDialog(null, "Error!", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }

            }


        }
    };

    // written by jack for import button
    private void importButtonActionPerformed(ActionEvent e) {
        String fileName = importTextfield.getText();

        if (fileName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a file name.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        File fileToImport = new File(fileName);

        if (!fileToImport.exists()) {
            JOptionPane.showMessageDialog(this, "File not found.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(fileToImport))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }

            // Set the text in the JTextAreas
            sendPanelTextfield.setText(content.toString());

            JOptionPane.showMessageDialog(this, "Import successful!", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error during import: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //This methods sets up the invis part of the settings page.
    public void settingsInvisibility() {
        try {
            selectInvisibleBox.removeAllItems();
            hitListBox.removeAllItems();
            if (users != null) {
                // add the users that aren't on the invisible hitlist
                // iterate through users
                for (int i = 0; i < users.size(); i++) {
                    // iterate through list
                    if (!self.getInvisibleHitlist().contains(users.get(i).getUsername()) &&
                            !users.get(i).getRole().equals(self.getRole())) {
                        //add user that are not on list
                        selectInvisibleBox.addItem(users.get(i).getUsername());
                    }
                }
                // for second dropdown add users on list

                for (String s : self.getInvisibleHitlist()) {
                    //s);
                    hitListBox.addItem(s);
                }
            }

        } catch (Exception er) {
            JOptionPane.showMessageDialog(null, "ERROR IN SETTINGS", "settings",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    //This method sets up the blocking aspect of the settings page.
    public void settingsBlocking() {
        try {

            selectBlockBox.removeAllItems();
            blockedUserBox.removeAllItems();
            if (users != null) {
                // add the users that aren't on the invisible hitlist
                // iterate through users
                for (int i = 0; i < users.size(); i++) {
                    // iterate through list
                    if (!self.getBlockingList().contains(users.get(i).getUsername()) &&
                            !users.get(i).getRole().equals(self.getRole())) {
                        //add user that are not on list
                        selectBlockBox.addItem(users.get(i).getUsername());
                    }
                }
                // for second dropdown add users on list

                for (String s : self.getBlockingList()) {
                    //s);
                    blockedUserBox.addItem(s);
                }
            }

        } catch (Exception er) {
            JOptionPane.showMessageDialog(null, "ERROR IN SETTINGS", "settings",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void run() {
        JFrame f = new JFrame();

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setPreferredSize(new Dimension(600, 700));
        JPanel controls = new JPanel();

        client = new Client();
        f.add(client, BorderLayout.CENTER);
        f.add(controls, BorderLayout.SOUTH);


        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    /*
    PRIVATE BUILD METHODS
     */
    private JPanel buildConnectivityPage() {
        Page ConnectivityPage = new Page(CONNECTIVITY_PAGE);
        JPanel connectivityPage = new JPanel(new BorderLayout());
        connectivityPage.setLayout(new GridLayout(4, 4));

        connectivityPage.add(new JLabel("Please enter the IP")); //Title Label

        //Text field that will take in the ip
        ipField = new JTextField("");
        connectivityPage.add(ipField);


        connectivityPage.add(new JLabel("Please enter the port number"));
        //Text field that will take in the ip
        portTextField = new JTextField("");
        connectivityPage.add(portTextField);

        //Button that will initiate the connection process
        connectButton = new JButton("Connect");
        connectButton.addActionListener(actionListener);
        connectivityPage.add(connectButton);

        ConnectivityPage.add(connectivityPage);
        return ConnectivityPage;
    }

    private JPanel buildWelcomePage() {
        Page WelcomePage = new Page(WELCOME_PAGE);
        JPanel welcomePage = new JPanel(new BorderLayout());
        JPanel buttonsPanel = new JPanel(new GridLayout(1, 3));

        JLabel welcomeLabel = new JLabel("Welcome to eCommerce Conversations!");
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);

        welcomePageLoginButton = createMainButton("Login");
        welcomePageSignupButton = createMainButton("Signup");


        welcomePageLoginButton.addActionListener(actionListener);
        welcomePageSignupButton.addActionListener(actionListener);

        buttonsPanel.add(welcomePageLoginButton);
        buttonsPanel.add(welcomePageSignupButton);


        welcomePage.add(welcomeLabel, BorderLayout.NORTH);
        welcomePage.add(buttonsPanel, BorderLayout.CENTER);
        WelcomePage.setLayout(new BorderLayout());
        WelcomePage.add(welcomePage, BorderLayout.CENTER);
        return WelcomePage;
    }

    private JPanel buildLoginPage() {
        Page LoginPage = new Page(LOGIN_PAGE);
        JPanel loginPage = new JPanel();
        loginPage.setLayout(new GridLayout(4, 1));
        loginPage.setName("Login");

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        loginPageUsernameField = new JTextField();
        loginPagePasswordField = new JPasswordField();

        loginPageLoginButton = new JButton("Login");
        loginPageBackButton = new JButton("Back");

        loginPage.add(usernameLabel);
        loginPage.add(loginPageUsernameField);
        loginPage.add(passwordLabel);
        loginPage.add(loginPagePasswordField);
        loginPage.add(loginPageLoginButton);
        loginPage.add(loginPageBackButton);

        loginPageLoginButton.addActionListener(actionListener);

        loginPageBackButton.addActionListener(actionListener);

        LoginPage.add(loginPage);
        return LoginPage;
    }

    private JPanel buildSignupPage() {
        Page SignupPage = new Page(SIGN_UP_PAGE);
        JPanel signupPage = new JPanel();
        signupPage.setLayout(new GridLayout(6, 1));
        signupPage.setName("Signup");

        JLabel newUsernameLabel = new JLabel("Username:");
        JLabel newPasswordLabel = new JLabel("Password:");
        JLabel userTypeLabel = new JLabel("User Type:");
        newUsernameLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        newPasswordLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        userTypeLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        signupPageUsernameField = new JTextField();
        signupPagePasswordField = new JPasswordField();
        signupPageUserTypeDropdown = new JComboBox<>(new String[]{"Customer", "Seller"});
        signupPageUserTypeDropdown.setFont(new Font("Arial", Font.PLAIN, 18));

        signupPageStoreField = new JTextField();
        signupPageStoreField.setEnabled(false);

        signupPageSignupButton = new JButton("Signup");
        signupPageBackButton = new JButton("Back");

        signupPage.add(newUsernameLabel);
        signupPage.add(signupPageUsernameField);
        signupPage.add(newPasswordLabel);
        signupPage.add(signupPagePasswordField);
        signupPage.add(userTypeLabel);
        signupPage.add(signupPageUserTypeDropdown);
        signupPage.add(signupPageSignupButton);
        signupPage.add(signupPageBackButton);

        signupPageSignupButton.addActionListener(actionListener);
        signupPageBackButton.addActionListener(actionListener);

        SignupPage.add(signupPage);
        return SignupPage;
    }

    private JPanel buildFirstStorePage() {
        Page FirstStorePage = new Page(FIRST_STORE_PAGE);

        JLabel firstStoreLabel = new JLabel("Enter the name of your first store:");

        JPanel firstStore = new JPanel();

        firstStoreText = new JTextField(10);
        firstStoreButton = new JButton("Enter");
        firstStoreButton.addActionListener(actionListener);
        firstStoreButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        firstStoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        firstStoreText.setAlignmentX(Component.CENTER_ALIGNMENT);
        firstStore.add(firstStoreLabel);
        firstStore.add(firstStoreText);
        firstStore.add(firstStoreButton);
        firstStore.setLayout(new BoxLayout(firstStore, BoxLayout.Y_AXIS));

        FirstStorePage.add(firstStore);
        return FirstStorePage;

    }

    private JPanel buildCustomerPage() {
        Page CustomerPage = new Page(CUSTOMER_PAGE);
        JPanel panel = new JPanel(new GridLayout(3, 1));
        messageStores = new JButton("Messages Stores");
        messageStores.setFont(new Font("Arial", Font.PLAIN, 20));
        messageStores.addActionListener(actionListener);
        panel.add(messageStores);

        customerSettings = new JButton("Settings");
        customerSettings.setFont(new Font("Arial", Font.PLAIN, 20));
        customerSettings.addActionListener(actionListener);
        panel.add(customerSettings);

        customerPageLogout = new JButton("Logout");
        customerPageLogout.setFont(new Font("Arial", Font.PLAIN, 20));
        customerPageLogout.addActionListener(actionListener);
        panel.add(customerPageLogout);
        CustomerPage.setLayout(new BorderLayout());


        CustomerPage.add(panel, BorderLayout.CENTER);
        return CustomerPage;
    }

    private JPanel buildStoreManagerPage() {
        Page StoreManagerPage = new Page(STORE_MANAGER_PAGE);

        JPanel storeManagerPanel = new JPanel();
        JLabel storeManagerTitle = new JLabel("Store Manager");
        JLabel addStoreLabel = new JLabel("Add Store");
        addStoreText = new JTextField(10);
        addStoreButton = new JButton("Add");
        addStoreButton.addActionListener(actionListener);
        JLabel removeStoreLabel = new JLabel("Remove Store");

        removeStoreText = new JTextField(10);
        removeStoreButton = new JButton("Remove");
        removeStoreButton.addActionListener(actionListener);
        JLabel chooseWorkingStoreLabel = new JLabel("Choose a store to work from.");


        //TODO fill stores list with real stores

        storeManagerSelectStoreButton = new JButton("Select");
        storeManagerSelectStoreButton.addActionListener(actionListener);
        storeDropdownList = new JComboBox(stores);
        logoutFromStoreManager = new JButton("Logout");
        logoutFromStoreManager.addActionListener(actionListener);
        storeManagerTitle.setFont(new Font("Serif", Font.PLAIN, 40));
        storeManagerTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        addStoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        addStoreText.setAlignmentX(Component.CENTER_ALIGNMENT);
        addStoreButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        removeStoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        removeStoreText.setAlignmentX(Component.CENTER_ALIGNMENT);
        removeStoreButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        chooseWorkingStoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        storeDropdownList.setAlignmentX(Component.CENTER_ALIGNMENT);
        storeManagerSelectStoreButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutFromStoreManager.setAlignmentX(Component.CENTER_ALIGNMENT);


        storeManagerPanel.add(storeManagerTitle);
        storeManagerPanel.add(addStoreLabel);
        storeManagerPanel.add(addStoreText);
        storeManagerPanel.add(addStoreButton);
        storeManagerPanel.add(removeStoreLabel);
        storeManagerPanel.add(removeStoreText);
        storeManagerPanel.add(removeStoreButton);
        storeManagerPanel.add(chooseWorkingStoreLabel);
        storeManagerPanel.add(storeDropdownList);
        storeManagerPanel.add(storeManagerSelectStoreButton);
        storeManagerPanel.add(logoutFromStoreManager);

        storeManagerPanel.setLayout(new BoxLayout(storeManagerPanel, BoxLayout.Y_AXIS));

        StoreManagerPage.add(storeManagerPanel);
        return StoreManagerPage;

    }

    private JPanel buildSettingsPage() {
        Page SettingsPage = new Page(SETTINGS_PAGE);

        JPanel settingsHelperPanel = new JPanel();
        JLabel settingsLabel = new JLabel("SETTINGS");
        JPanel settings = new JPanel();

        selectInvisibleBox = new JComboBox<String>();
        hitListBox = new JComboBox<String>();
        // selectInvisibleBox.addActionListener(actionListener);
        JLabel usersYouAreVisableTo = new JLabel("You are visible to these users:");
        usersYouAreVisableTo.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(usersYouAreVisableTo);
        selectInvisibleBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(selectInvisibleBox);

        becomeInvisible = new JButton("Become Invisible To");
        becomeInvisible.addActionListener(actionListener);
        becomeInvisible.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(becomeInvisible);

        becomeVisible = new JButton("Become Visible To");
        becomeVisible.addActionListener(actionListener);
        becomeVisible.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel usersYouAreInvisibleTo = new JLabel("You are invisible to these users:");
        usersYouAreInvisibleTo.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(usersYouAreInvisibleTo);
        hitListBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(hitListBox);
        settings.add(becomeVisible);

        selectBlockBox = new JComboBox<String>();
        blockedUserBox = new JComboBox<String>();
        JLabel usersYouAreNotBlocking = new JLabel("You are not blocking these users:");
        usersYouAreNotBlocking.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(usersYouAreNotBlocking);
        selectBlockBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(selectBlockBox);

        blockUser = new JButton("Block User");
        blockUser.addActionListener(actionListener);
        blockUser.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(blockUser);

        unblockUser = new JButton("Unblock User");
        unblockUser.addActionListener(actionListener);
        unblockUser.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel usersYouAreBlocking = new JLabel("You are blocking these users:");
        usersYouAreBlocking.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(usersYouAreBlocking);
        blockedUserBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(blockedUserBox);
        settings.add(unblockUser);

        returnToRolePage = new JButton("Back");
        returnToRolePage.addActionListener(actionListener);
        returnToRolePage.setAlignmentX(Component.CENTER_ALIGNMENT);
        settings.add(returnToRolePage);

        settings.setLayout(new BoxLayout(settings, BoxLayout.Y_AXIS));

        settingsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        settingsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        settingsHelperPanel.add(settingsLabel);
        settingsHelperPanel.add(settings);


        settingsHelperPanel.setLayout(new BoxLayout(settingsHelperPanel, BoxLayout.Y_AXIS));

        SettingsPage.add(settingsHelperPanel);

        return SettingsPage;
    }

    private JPanel buildSellerPage() {
        Page SellerPage = new Page(SELLER_PAGE);
        JPanel sellerPanel = new JPanel(new GridLayout(4, 1));


        messageCustomers = new JButton("Message Customers");
        messageCustomers.setFont(new Font("Arial", Font.PLAIN, 20));

        messageCustomers.addActionListener(actionListener);
        sellerPanel.add(messageCustomers);

        sellerPageSettingsButton = new JButton("Settings");
        sellerPageSettingsButton.setFont(new Font("Arial", Font.PLAIN, 20));
        sellerPageSettingsButton.addActionListener(actionListener);
        sellerPanel.add(sellerPageSettingsButton);

        sellerPageLogout = new JButton("Logout");
        sellerPageLogout.setFont(new Font("Arial", Font.PLAIN, 20));
        sellerPageLogout.addActionListener(actionListener);
        sellerPanel.add(sellerPageLogout);

        returnToStoreManager = new JButton("Return to Store Manager");
        returnToStoreManager.setFont(new Font("Arial", Font.PLAIN, 20));
        returnToStoreManager.addActionListener(actionListener);
        sellerPanel.add(returnToStoreManager);
        SellerPage.setLayout(new BorderLayout());
        SellerPage.add(sellerPanel, BorderLayout.CENTER);

        return SellerPage;
    }

    private JPanel buildSelectCustomerPage() {
        //TODO change this to outside the frame
        Page SelectCustomerPage = new Page(SELECT_CUSTOMER_PAGE);
        JPanel selectCustomer = new JPanel(); //Housing for all the components for this page
        selectCustomer.setLayout(new BoxLayout(selectCustomer, BoxLayout.Y_AXIS));//Creates layout to stack components

        //Already talked to
        JLabel title = new JLabel("Select Customer");
        title.setAlignmentX(SwingConstants.CENTER);
        selectCustomer.add(title); //Title of the page
        //TODO: put the array that has all the visible user in here

        //Already talked to
        customersAlreadyTalked = new DefaultListModel();
        //Create the list and put it in a scroll pane.
        customerList1 = new JList(customersAlreadyTalked);

        customerList1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        customerList1.setSelectedIndex(0);
        customerList1.setVisibleRowCount(5);

        JScrollPane listScrollPane = new JScrollPane(customerList1);
        listScrollPane.setAlignmentX(SwingConstants.CENTER);
        //New convo
        customersNotTalked = new DefaultListModel();

        //Create the list and put it in a scroll pane.
        customerList2 = new JList(customersNotTalked);
        customerList2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        customerList2.setSelectedIndex(0);

        customerList2.setVisibleRowCount(5);
        JScrollPane listScrollPane2 = new JScrollPane(customerList2);
        listScrollPane2.setAlignmentX(SwingConstants.CENTER);


        JLabel oldUsers = new JLabel("Conversations have been started with these customers:");
        oldUsers.setAlignmentX(SwingConstants.CENTER);
        JLabel newUsers = new JLabel("Conversations have not been started with these customers yet:");
        newUsers.setAlignmentX(SwingConstants.CENTER);
        selectCustomerPageSelectCustomerButtonOld = new JButton("Enter Conversation");
        selectCustomerPageSelectCustomerButtonOld.addActionListener(actionListener);
        selectCustomerPageSelectCustomerButtonNew = new JButton("New Conversation");
        selectCustomerPageSelectCustomerButtonNew.addActionListener(actionListener);


        JPanel helper1 = new JPanel();
        oldUsers.setAlignmentX(SwingConstants.CENTER);
        helper1.add(oldUsers);
        listScrollPane.setAlignmentX(SwingConstants.CENTER);
        helper1.add(listScrollPane);
        selectCustomerPageSelectCustomerButtonOld.setAlignmentX(SwingConstants.CENTER);
        helper1.add(selectCustomerPageSelectCustomerButtonOld);
        helper1.setLayout(new BoxLayout(helper1, BoxLayout.Y_AXIS));

        JPanel helper2 = new JPanel();
        newUsers.setAlignmentX(SwingConstants.CENTER);
        helper2.add(newUsers);
        listScrollPane2.setAlignmentX(SwingConstants.CENTER);
        helper2.add(listScrollPane2);
        selectCustomerPageSelectCustomerButtonNew.setAlignmentX(SwingConstants.CENTER);
        helper2.add(selectCustomerPageSelectCustomerButtonNew);
        helper2.setLayout(new BoxLayout(helper2, BoxLayout.Y_AXIS));

        JPanel helper3 = new JPanel();
        helper3.add(helper1);
        helper3.add(helper2);
        helper3.setAlignmentX(SwingConstants.CENTER);
        selectCustomer.add(helper3);
        JButton refreshButton = new JButton("Refresh Customer List");
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    refresh();
                    selectCustomer();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        selectCustomer.add(refreshButton);
        //listener
        selectCustomerBackButton = new JButton("\u22b2Back");
        selectCustomerBackButton.addActionListener(actionListener);
        selectCustomerBackButton.setAlignmentX(SwingConstants.CENTER);
        selectCustomer.add(selectCustomerBackButton);
        // vertically
        selectCustomer.setAlignmentX(SwingConstants.CENTER);


        SelectCustomerPage.add(selectCustomer); //Adds panel to the Page

        return SelectCustomerPage;
    }

    private JPanel buildSelectSellerPage() {
        Page SelectSellerPage = new Page(SELECT_SELLER_PAGE);
        JPanel selectSeller = new JPanel(); //Housing for all the components for this page
        selectSeller.add(new JLabel("Select Seller")); //Title of the page

        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    refresh();
                    selectSellerComboBox.removeAllItems();
                    for (int i = 0; i < users.size(); i++) {
                        if (users.get(i).getRole().equals("S") &&
                                !users.get(i).getInvisibleHitlist().contains(self.getUsername())) {
                            selectSellerComboBox.addItem(users.get(i).getUsername());
                        }
                    }
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        //TODO: put the array that has all the visible user in here

        selectSellerComboBox = new JComboBox<String>();
        selectSellerButton = new JButton("Select");
        selectSellerButton.addActionListener(actionListener);
        selectSellerBackButton = new JButton("\u22b2Back");
        selectSellerBackButton.addActionListener(actionListener);
        selectSeller.add(selectSellerComboBox); //Will display the array containing all the visible customers
        selectSeller.add(selectSellerButton); //Will initiate the select seller logic in the action
        //listener
        selectSeller.add(refreshButton);
        selectSeller.add(selectSellerBackButton);
        selectSeller.setLayout(new BoxLayout(selectSeller, BoxLayout.Y_AXIS)); //stack components vertically
        SelectSellerPage.add(selectSeller); //Adds panel to the Page

        return SelectSellerPage;
    }

    private JPanel buildSelectStorePage() { //SPECIFIC GO BACK
        Page SelectStorePage = new Page(SELECT_STORE_PAGE);
        JPanel selectStore = new JPanel(); //Housing for all the components for this page
        JLabel title = new JLabel("Select Store");
        title.setAlignmentX(SwingConstants.CENTER);
        selectStore.add(title); //Title of the page
        JButton refreshButton = new JButton("Refresh");

        //Already talked to
        storesAlreadyTalked = new DefaultListModel();
        //Create the list and put it in a scroll pane.
        storesList1 = new JList(storesAlreadyTalked);

        storesList1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        storesList1.setSelectedIndex(0);
        storesList1.setVisibleRowCount(5);

        JScrollPane listScrollPane = new JScrollPane(storesList1);
        listScrollPane.setAlignmentX(SwingConstants.CENTER);
        //New convo
        storesNotTalked = new DefaultListModel();

        //Create the list and put it in a scroll pane.
        storesList2 = new JList(storesNotTalked);
        storesList2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        storesList2.setSelectedIndex(0);

        storesList2.setVisibleRowCount(5);
        JScrollPane listScrollPane2 = new JScrollPane(storesList2);
        listScrollPane2.setAlignmentX(SwingConstants.CENTER);


        JLabel oldUsers = new JLabel("Conversations have been started with these stores:");

        JLabel newUsers = new JLabel("Conversations have not been started with these stores yet:");

        selectStorePageSelectStoreButtonOld = new JButton("Select a previous conversation");
        selectStorePageSelectStoreButtonOld.addActionListener(actionListener);
        selectStorePageSelectStoreButtonNew = new JButton("New conversation");
        selectStorePageSelectStoreButtonNew.addActionListener(actionListener);


        JPanel helper1 = new JPanel();
        oldUsers.setAlignmentX(SwingConstants.CENTER);
        helper1.add(oldUsers);
        listScrollPane.setAlignmentX(SwingConstants.CENTER);
        helper1.add(listScrollPane);
        selectStorePageSelectStoreButtonOld.setAlignmentX(SwingConstants.CENTER);
        helper1.add(selectStorePageSelectStoreButtonOld);
        helper1.setLayout(new BoxLayout(helper1, BoxLayout.Y_AXIS));

        JPanel helper2 = new JPanel();
        newUsers.setAlignmentX(SwingConstants.CENTER);
        helper2.add(newUsers);
        listScrollPane2.setAlignmentX(SwingConstants.CENTER);
        helper2.add(listScrollPane2);
        selectStorePageSelectStoreButtonNew.setAlignmentX(SwingConstants.CENTER);
        helper2.add(selectStorePageSelectStoreButtonNew);
        helper2.setLayout(new BoxLayout(helper2, BoxLayout.Y_AXIS));

        JPanel helper3 = new JPanel();
        helper3.add(helper1);
        helper3.add(helper2);
        helper3.setAlignmentX(SwingConstants.CENTER);
        selectStore.add(helper3);

        selectStore.add(refreshButton);
        //listener
        selectStoreBackButton = new JButton("\u22b2Back");
        selectStoreBackButton.addActionListener(actionListener);
        selectStoreBackButton.setAlignmentX(SwingConstants.CENTER);
        selectStore.add(selectStoreBackButton);
        selectStore.setLayout(new BoxLayout(selectStore, BoxLayout.Y_AXIS));//Creates layout to stack components
        // vertically
        selectStore.setAlignmentX(SwingConstants.CENTER);
        SelectStorePage.add(selectStore); //Adds panel to the Page
        SelectStorePage.setAlignmentX(SwingConstants.CENTER);

        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    refresh();
                    storesNotTalked.removeAllElements();
                    storesAlreadyTalked.removeAllElements();
                    String sellerName = (String) selectSellerComboBox.getSelectedItem(); //Gets the seller name

                    //looks for that seller in the users list
                    User seller = null;
                    for (User u : users) {
                        if (u.getUsername().equals(sellerName)) {
                            seller = u;
                            break;
                        }
                    }

                    out.println("talkedTo--" + self.getUsername());
                    //All the customers this store has talked to.
                    ArrayList<String> talkedTo = (ArrayList<String>) objectIn.readObject();
                    String reply = in.readLine();
                    if (reply.equals("talkedTo Success")) {
                        //Were looking through all of the users (really just all of the customers)
                        //add talkedTo to select customer
                        for (int i = 0; i < talkedTo.size(); i++) {
                            //finds the user and check to see if the current iterated user does not have self in their
                            //invisibility hit list
                            String iteratedStore = "";
                            if (seller.getStores().contains(talkedTo.get(i))) {
                                if (!seller.getInvisibleHitlist().contains(talkedTo.get(i))) {
                                    storesAlreadyTalked.addElement(talkedTo.get(i));
                                }
                            }
                        }

                        //find user that
                        for (String s : seller.getStores()) {
                            if (!talkedTo.contains(s)) {
                                if (!seller.getInvisibleHitlist().contains(s)) {
                                    storesNotTalked.addElement(s);
                                }
                            }
                        }

                        changePage(SELECT_STORE_PAGE);
                    }
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        return SelectStorePage;

    }

    private JPanel buildConversationMenu() {
        Page ConversationMenu = new Page(CONVERSATION_MENU);
        JPanel sendPanel = new JPanel();
        JButton refreshButton = new JButton("Click to Refresh Chat!");
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // refreshing the entire page here
                try {
                    if (self.getRole().equals("C")) {
                        reloadChatLog(target);
                    } else {
                        //dummy user
                        User user = new User(" ", target, " ", false);
                        reloadChatLog(user);
                    }
                    sendPanelPreviousConvo.setText(currentChat);
                    deletePanelPreviousConvo.setText(currentChat);
                    editPanelPreviousConvo.setText(currentChat);
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });


        //Just testing remove this try/catch later

        sendPanelPreviousConvo = new JLabel(currentChat);

        sendPanelScrollPane = new JScrollPane(sendPanelPreviousConvo,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        sendPanelScrollPane.setPreferredSize(new Dimension(350, 350));

        sendPanel.setLayout(new BorderLayout());
        JLabel sendPanelMessageHistory = new JLabel("Conversation History", SwingConstants.CENTER);
        sendPanel.add(sendPanelMessageHistory, BorderLayout.NORTH);
        sendPanel.add(sendPanelScrollPane, BorderLayout.CENTER);

        JPanel sendPanelMessagePanel = new JPanel();
        sendPanelSendButton = new JButton("Send Message");
        sendPanelSendButton.addActionListener(actionListener);
        sendPanelTextfield = new JTextField(20);
        sendPanelMessagePanel.add(sendPanelTextfield);
        sendPanelMessagePanel.add(sendPanelSendButton);

        sendPanel.add(sendPanelMessagePanel, BorderLayout.SOUTH);


        JPanel deletePanel = new JPanel();
        //TODO We are only showing the current users messages.
        deletePanelPreviousConvo = new JLabel();
        deletePanelScrollPane = new JScrollPane(deletePanelPreviousConvo,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        deletePanelScrollPane.setPreferredSize(new Dimension(450, 400));
        deletePanel.setLayout(new BorderLayout());
        JLabel deletePageMessageHistory = new JLabel("Conversation History", SwingConstants.CENTER);

        deletePanel.add(deletePageMessageHistory, BorderLayout.NORTH);
        deletePanel.add(deletePanelScrollPane, BorderLayout.CENTER);

        JPanel deletePageMessagePanel = new JPanel();
        deletePageButton = new JButton("Delete");
        deletePageButton.addActionListener(actionListener);
        deletePageTextfield = new JTextField(5);
        JLabel deletePageNumberLabel = new JLabel("Enter the line number you would like to delete:");
        deletePageMessagePanel.add(deletePageNumberLabel);
        deletePageMessagePanel.add(deletePageTextfield);
        deletePageMessagePanel.add(deletePageButton);

        deletePanel.add(deletePageMessagePanel, BorderLayout.SOUTH);


        JPanel editPanel = new JPanel();
        editPanelPreviousConvo = new JLabel();

        editPanelScrollPane = new JScrollPane(editPanelPreviousConvo,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        editPanelScrollPane.setPreferredSize(new Dimension(450, 400));
        editPanel.setLayout(new BorderLayout());
        JLabel editPageMessageHistory = new JLabel("Conversation History", SwingConstants.CENTER);

        editPanel.add(editPageMessageHistory, BorderLayout.NORTH);
        editPanel.add(editPanelScrollPane, BorderLayout.CENTER);

        JPanel editPageMessagePanel = new JPanel(new GridLayout(2, 1));


        JLabel editPageNumberLabel = new JLabel("Enter the line number you would like to edit:");
        editPageNumberTextfield = new JTextField(5);

        JPanel helper2 = new JPanel();
        helper2.add(editPageNumberLabel);
        helper2.add(editPageNumberTextfield);

        editPageButton = new JButton("Send Edit");
        editPageButton.addActionListener(actionListener);
        helper2.add(editPageButton);

        JLabel editPageMessageLabel = new JLabel("Enter the edited message:");
        editPageMessageTextfield = new JTextField(20);

        JPanel helper3 = new JPanel();
        helper3.add(editPageMessageLabel);
        helper3.add(editPageMessageTextfield);

        editPageMessagePanel.add(helper2);
        editPageMessagePanel.add(helper3);
        editPanel.add(editPageMessagePanel, BorderLayout.SOUTH);


        JPanel importPanel = new JPanel(new BorderLayout());
        JPanel helper4 = new JPanel();

        JLabel importLabel = new JLabel("Enter the file name of the file you would like to import:");
        importTextfield = new JTextField(10);
        importButton = new JButton("Import");
        importButton.addActionListener(actionListener);

        helper4.add(importLabel);
        helper4.add(importTextfield);
        helper4.add(importButton);
        importPanel.add(helper4, BorderLayout.CENTER);


        JPanel exportPanel = new JPanel(new BorderLayout());
        exportPanel.setPreferredSize(new Dimension(300, 300));
        JPanel helper5 = new JPanel();
        JLabel exportLabel = new JLabel("<html>Please click the button if you would like to export this" +
                " conversation.<br/>" + " The exported file type will be a .csv.<html>");
        exportButton = new JButton("Export This Conversation");
        exportButton.addActionListener(actionListener);
        helper5.add(exportLabel);
        helper5.add(exportButton);
        exportPanel.add(helper5, BorderLayout.CENTER);

        JPanel blockPanel = new JPanel();
        currentBlockStatus = new JLabel("You are currently blocking this conversation");
        blockButton = new JToggleButton("Blocked");
        blockButton.addActionListener(actionListener);
        blockPanel.add(currentBlockStatus);
        blockPanel.add(blockButton);

        tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setPreferredSize(new Dimension(500, 500));
        tabbedPane.add("Send", sendPanel);
        tabbedPane.add("Delete", deletePanel);
        tabbedPane.add("Edit", editPanel);
        tabbedPane.add("Import", importPanel);
        tabbedPane.add("Export", exportPanel);
        tabbedPane.add("Block", blockPanel);
        conversationMenuBack = new JButton("\u22b2Back");
        conversationMenuBack.addActionListener(actionListener);
        JPanel helper = new JPanel();


        helper.setLayout(new BorderLayout());
        title = new JLabel("You are messaging:", SwingConstants.CENTER);
        helper.add(title, BorderLayout.PAGE_START);
        helper.add(refreshButton, BorderLayout.NORTH);
        helper.add(tabbedPane, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new GridLayout(1, 2));
        buttons.add(conversationMenuBack);
        buttons.add(refreshButton);
        helper.add(buttons, BorderLayout.SOUTH);

        ConversationMenu.add(helper);

        return ConversationMenu;
    }

    /*
    Use changePage() to traverse the different pages!
     */
    public void changePage(String key) {
        cardLayout.show(cards, key);
    }

    /*
    MISC METHODS
     */
    private void enableStoreField(boolean enable) {
        storeField.setEnabled(enable);
    }


    /*
    FRAME/COMPONENT HELPER METHODS
     */
    private JButton createMainButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.PLAIN, 20));
        return button;
    }

    private void centerFrameOnScreen() {
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (dim.width - frame.getSize().width) / 2;
        int y = (dim.height - frame.getSize().height) / 2;
        frame.setLocation(x, y);
    }

    /*
    I/O HELPER METHODS
     */

    //Updates the locally stored data with new data from the server
    //Calls whenever a page is moved
    //SHOULD ONLY BE CALLED AFTER CONNECTING AND DURING THE USER SELECTION PAGES
    private void refresh() throws IOException, ClassNotFoundException {
        out.println("refresh");
        if (users != null) {
            users.clear(); //Clears the user ArrayList
        } else {
            users = new CopyOnWriteArrayList<>();
        }


        String currentToString; //Stores the current toString that the server sent at that moment

        //Take the one big toString and split it.

        users = (CopyOnWriteArrayList<User>) objectIn.readObject();

        //objectOut.writeObject(null); //Passing the ball back to the server

        out.println("Received users");

        if (!firstRefresh) {
            self = (User) objectIn.readObject();
            for (int i = 0; i < users.size(); i++) {
                if (users.get(i).getUsername().equals(self.getUsername())) {
                    users.set(i, self);
                }
            }
        }
        if (in.readLine().equals("Refreshed")) {
            firstRefresh = false;
        }
    }

    private void firstRefresh() throws IOException, ClassNotFoundException {
        out.println("firstRefresh");
        if (users != null) {
            users.clear(); //Clears the user ArrayList
        } else {
            users = new CopyOnWriteArrayList<>();
        }


        String currentToString; //Stores the current toString that the server sent at that moment

        //Take the one big toString and split it.

        users = (CopyOnWriteArrayList<User>) objectIn.readObject();

        //objectOut.writeObject(null); //Passing the ball back to the server

        out.println("Received users");

        if (in.readLine().equals("Refreshed")) {
            firstRefresh = false;
        }
    }

    //Reloads the chat logs of the target if the current user is a Customer
    private void reloadChatLog(String targetStore) throws IOException, ClassNotFoundException {
        //Sends command to the server to reload the chat log for the Customer
        out.println("reloadChatLog--" + self.getUsername() + "--" + targetStore);
        currentChat = in.readLine(); //Stores the chat on the ArrayList
    }

    //Reloads the chat logs of the target if the current user is a Seller
    private void reloadChatLog(User target) throws IOException, ClassNotFoundException {
        //Sends command to the server to reload the chat log for the Seller
        out.println("reloadChatLog--" + self.getCurrentStore() + "--" + target.getUsername());
        currentChat = in.readLine(); //Stores the chat on the ArrayList
    }

    private void sendMessage(String message, Object target) {
        //string store or object user
        //string
        //Executes differently if the target is a Customer or a store
        //self.getRole());

        if (target instanceof String) { //target is a store
            out.println("addMessage--" + self.getUsername() + "--" + target + "--" + message);
        } else if (target instanceof User) { //target is a customer
            out.println("addMessage--" + self.getCurrentStore() + "--" + ((User) target).getUsername() + "--"
                    + message);
        }
    }

    private void deleteMessage(String displayLineStr, Object target) {
        int displayLine;

        //Checks if the input is valid
        try {
            displayLine = Integer.parseInt(displayLineStr); //try to parse the string into an integer
            Pattern pattern = Pattern.compile("[^<b>]*<b>");
            Matcher matcher = pattern.matcher(currentChat);
            int chatSize = 0;
            while (matcher.find()) {
                chatSize++;
            }
            //Throws an error if the displayLine is out of the bounds of the arrayList
            if (chatSize < displayLine || displayLine < 0) {
                JOptionPane.showMessageDialog(null, "Error! This line number is invalid",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            //If the input is invalid, through the error and stop the program
            invalidInputError();
            return;
        }

        //Executes differently if the target is a Customer or a Store
        if (target instanceof String) { //target is a store
            out.println("deleteMessage--" + self.getUsername() + "--" + target + "--" + displayLine);
        } else if (target instanceof User) { //target is a Customer
            out.println("deleteMessage--" + self.getCurrentStore() + "--" + ((User) target).getUsername() + "--" +
                    displayLine);
        }
        try {
            String reply = in.readLine();

            if (reply.equals("IllegalDeletion")) {
                JOptionPane.showMessageDialog(null, "You cannot delete a message that you " +
                                "did not send!", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else if (reply.equals("Deleted")) {
                if (self.getRole().equals("C")) {
                    reloadChatLog((String) target);
                } else {
                    reloadChatLog((User) target);
                }

                refresh();
                deletePanelPreviousConvo.setText(currentChat);
                //update edit and send
                sendPanelPreviousConvo.setText(currentChat);
                editPanelPreviousConvo.setText(currentChat);
                deletePanelScrollPane.revalidate();
            }
        } catch (Exception e) {

        }
    }


    private void modifyMessage(String displayLineStr, Object target, String newMessage) {
        int displayLine;

        //Checks if the input is valid
        try {
            displayLine = Integer.parseInt(displayLineStr); //try to parse the string into an integer
            Pattern pattern = Pattern.compile("[^<b>]*<b>");
            Matcher matcher = pattern.matcher(currentChat);
            int chatSize = 0;
            while (matcher.find()) {
                chatSize++;
            }
            //Throws an error if the displayLine is out of the bounds of the arrayList
            if (chatSize < displayLine || displayLine < 0) {
                JOptionPane.showMessageDialog(null, "Error! This line number is invalid",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            //If the input is invalid, through the error and stop the program
            invalidInputError();
            return;
        }

        //Executes differently if the target is a Customer or a Store
        if (target instanceof String) { //target is a store
            out.println("modifyMessage--" + self.getUsername() + "--" + target + "--" + displayLine +
                    "--" + newMessage);
        } else if (target instanceof User) { //target is a Customer
            out.println("modifyMessage--" + self.getCurrentStore() + "--" + ((User) target).getUsername() + "--" +
                    displayLine + "--" + newMessage);
        }
    }

    private void invalidInputError() {
        JOptionPane.showMessageDialog(cards, "Error! That input is invalid", "Error",
                JOptionPane.ERROR_MESSAGE);
    }


    private void login() {
        if (loginPageUsernameField.getText().equals("") || loginPagePasswordField.getText().equals("")
                || loginPageUsernameField.getText() == null || loginPagePasswordField.getText() == null) {
            JOptionPane.showMessageDialog(null, "You must enter a username and password!",
                    "Empty Fields", JOptionPane.ERROR_MESSAGE);
        } else {
            String username = loginPageUsernameField.getText();
            String password = loginPagePasswordField.getText();

            out.println("Login--" + username + "--" + password);
            //"Sent login attempt to server for validation");
            try {
                String accountValidation = in.readLine();
                if (accountValidation.equals("Success")) {
                    //"Success");
                    try {

                        self = (User) objectIn.readObject();
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, "Error!", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    //self.getUsername() + " connected to the server!");
                    if (self.getRole().equals("C")) {
                        changePage(CUSTOMER_PAGE);
                    } else {
                        //self.getStores());
                        stores = self.getStores().toArray(new String[0]);
                        storeDropdownList.removeAllItems();
                        for (int i = 0; i < stores.length; i++) {
                            storeDropdownList.addItem(stores[i]);
                        }

                        changePage(STORE_MANAGER_PAGE);
                    }
                } else {
                    //"Failed");
                    JOptionPane.showMessageDialog(null, "The username and password " +
                            "combination is not correct", "Incorect", JOptionPane.ERROR_MESSAGE);
                }
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error!", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public boolean validateInput(String name) {
        boolean result = true;
        Pattern p = Pattern.compile("[^a-zA-Z0-9]");
        //Find match between given string
        //and regular expression
        Matcher m = p.matcher(name);

        if (m.find()) { //if the name has any special characters, return false
            result = false;
        }
        return result;
    }

    public void signup() {
        //Only allow legal chars and no white space.
        if (signupPageUsernameField.getText().isBlank() || signupPagePasswordField.getText().isBlank()) {
            JOptionPane.showMessageDialog(null, "You must enter a username and password!",
                    "Empty Fields", JOptionPane.ERROR_MESSAGE);
            //TODO ADD A CONFIRM
        } else if (!(validateInput(signupPageUsernameField.getText())) ||
                !(validateInput(signupPagePasswordField.getText()))) {
            JOptionPane.showMessageDialog(null, "You used an illegal character, " +
                            "please try again. You may only use letters a-z, A-Z, " +
                            "and 0-9. No white space or other special chars is allowed.",
                    "Invalid Characters", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                String username = signupPageUsernameField.getText();
                String password = signupPagePasswordField.getText();
                String selectedRole = (String) signupPageUserTypeDropdown.getSelectedItem();
                String role = "";
                if (selectedRole.equals("Seller")) {
                    role = "S";
                } else {
                    role = "C";
                }
                //NOW FOR SOME backend validation
                //make sure this new account is actually unique and doesn't alr exist.
                out.println("Signup--" + username + "--" + password + "--" + role);
                String existence = in.readLine();
                //existence); // FOR testing
                if (existence.equals("Already Exists")) {
                    JOptionPane.showMessageDialog(null, "This username already exists. " +
                                    "Please try another username.",
                            "Username not unique", JOptionPane.ERROR_MESSAGE);
                } else if (existence.equals("Unique")) {
                    // add the new user
                    self = new User(role, username, password, false);

                    // then progress based on s/c
                    //SEND COMMAND TO SERVER to log this new user
                    // if signup as seller -> firstStore -> storeManager
                    if (self.getRole().equals("S")) {
                        changePage(FIRST_STORE_PAGE);
                    }
                    // if customer -> customerPage
                    if (self.getRole().equals("C")) {
                        changePage(CUSTOMER_PAGE);
                    }
                }

            } catch (IOException ioe) {
                JOptionPane.showMessageDialog(null, "Error!", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error!", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }

        }
    }

    public void firstStore() {
        if (firstStoreText.getText().isBlank()) {
            JOptionPane.showMessageDialog(null, "You must enter a store name!",
                    "Empty Field", JOptionPane.ERROR_MESSAGE);

        } else if (!(validateInput(firstStoreText.getText()))) {
            JOptionPane.showMessageDialog(null, "You used an illegal character, " +
                            "please try again. You may only use letters a-z, A-Z, " +
                            "and 0-9. No white space or other special chars is allowed.",
                    "Invalid Characters", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                String firstStore = firstStoreText.getText();
                out.println("addStore--" + firstStore);

                String reply = in.readLine();
                //reply);
                //"failed nonexistent"
                //"failed not unique
                if (reply.equals("Failed Not Unique")) {
                    JOptionPane.showMessageDialog(null, "This name already exists. " +
                                    "Please try another store name.",
                            "Store name not unique", JOptionPane.ERROR_MESSAGE);
                } else if (reply.equals("Added Successfully")) {
                    storeDropdownList.removeAllItems();
                    storeDropdownList.addItem(firstStore);

                    changePage(STORE_MANAGER_PAGE);
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error!", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }


        }
    }

    public void storeManager(int param) {
        if (param == 1) {
            //add
            if (addStoreText.getText().isBlank()) {
                JOptionPane.showMessageDialog(null, "You must enter a store name!",
                        "Empty Field", JOptionPane.ERROR_MESSAGE);
            } else if (!(validateInput(addStoreText.getText()))) {
                JOptionPane.showMessageDialog(null, "You used an illegal character, " +
                                "please try again. You may only use letters a-z, A-Z, " +
                                "and 0-9. No white space or other special chars is allowed.",
                        "Invalid Characters", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    String storeName = addStoreText.getText();

                    out.println("addStore--" + storeName);

                    String reply = in.readLine();

                    if (reply.equals("Failed Not Unique")) {
                        JOptionPane.showMessageDialog(null, "This name already exists. " +
                                        "Please try another store name.",
                                "Store name not unique", JOptionPane.ERROR_MESSAGE);

                    } else if (reply.equals("Added Successfully")) {
                        storeDropdownList.addItem(storeName);
                        JOptionPane.showMessageDialog(null, "Store successfully added",
                                "Successfully Added", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }


            }

        } else if (param == 2) {
            //remove
            if (removeStoreText.getText().isBlank()) {
                JOptionPane.showMessageDialog(null, "You must enter a store name!",
                        "Empty Field", JOptionPane.ERROR_MESSAGE);
            } else if (!(validateInput(removeStoreText.getText()))) {
                JOptionPane.showMessageDialog(null, "You used an illegal character, " +
                                "please try again. You may only use letters a-z, A-Z, " +
                                "and 0-9. No white space or other special chars is allowed.",
                        "Invalid Characters", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    String storeName = removeStoreText.getText();
                    out.println("removeStore--" + storeName);
                    String reply = in.readLine();

                    if (reply.equals("Failed Nonexistent")) {
                        JOptionPane.showMessageDialog(null, "You cannot remove this " +
                                        "store because it does not exist. Please try another store name.",
                                "Store does not exist", JOptionPane.ERROR_MESSAGE);

                    } else if (reply.equals("Deleted Successfully")) {
                        int size = storeDropdownList.getItemCount();
                        for (int i = 0; i < size; i++) {
                            if (storeDropdownList.getItemAt(i).equals(storeName)) {
                                storeDropdownList.removeItemAt(i);
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(null, "Store successfully removed",
                                "Successfully Removed", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }

            }

        } else if (param == 3) {
            //choose store to work from
            String store = (String) storeDropdownList.getSelectedItem();
            if (store != null) { //ensures that a store was actually selected
                self.setCurrentStore(store);

                out.println("setCurrentStore--" + self.getCurrentStore());

                try {
                    if (in.readLine().equals("Set Current Store")) {
                        refresh();
                        //progress happens here
                        changePage(SELLER_PAGE);
                    }
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } catch (ClassNotFoundException e) {
                    JOptionPane.showMessageDialog(null, "Error!", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }

            } else { //Throws error if the user tries to select a null store
                JOptionPane.showMessageDialog(null, "Error! Please select an existing store.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void selectCustomer() {
        //self is a Seller;
        try {
            refresh();
            customersAlreadyTalked.removeAllElements();
            customersNotTalked.removeAllElements();
            out.println("talkedTo--" + self.getCurrentStore());
            //All the customers this store has talked to.
            ArrayList<String> talkedTo = (ArrayList<String>) objectIn.readObject();
            String reply = in.readLine();
            if (reply.equals("talkedTo Success")) {
                //Were looking through all of the users (really just all of the customers)
                //add talked to to select customer
                for (int i = 0; i < talkedTo.size(); i++) {
                    //will find the user and check to see if the current iterated user does not have self in their
                    //invisibility hit list
                    User iteratedUser = null;
                    for (User u : users) {
                        if (talkedTo.get(i).equals(u.getUsername())) {
                            iteratedUser = u;
                            break;
                        }
                    }

                    //If the iteratedUser does not have self on their invisibleHitlist, then display the user
                    if (!iteratedUser.getInvisibleHitlist().contains(self.getUsername())) {
                        customersAlreadyTalked.addElement(talkedTo.get(i));
                    }
                }


                for (int i = 0; i < users.size(); i++) {
                    if (users.get(i).getRole().equals("C")) { //checks if user is a customer

                        //Checks if the iterated user does not have self on their invisibility hitlist
                        if (!users.get(i).getInvisibleHitlist().contains(self.getUsername())) {

                            //Checks to see if self has already talked to the iterated user before
                            if (!talkedTo.contains(users.get(i).getUsername())) {
                                customersNotTalked.addElement(users.get(i).getUsername());
                            }
                        }
                    }
                }


                changePage(SELECT_CUSTOMER_PAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

    public void updateTargetSellersStores() {
        //self is a Customer.

        try {
            refresh();
            String seller = (String) selectSellerComboBox.getSelectedItem();
            //make sure to remove all elements beforehand to prevent any double cases.
            storesAlreadyTalked.removeAllElements();
            storesNotTalked.removeAllElements();
            out.println("talkedTo--" + self.getUsername());
            ArrayList<String> talkedTo = (ArrayList<String>) objectIn.readObject();
            //talkedTo);
            String reply = in.readLine();
            if (reply.equals("talkedTo Success")) {
                //We're going to get a list of the sellers stores.
                ArrayList<String> sellersStores = new ArrayList<>();
                for (User i : users) {
                    if (i.getUsername().equals(seller)) {
                        sellersStores = i.getStores();
                        break;
                    }
                }
                //sellersStores);
                //Out of all the sellers available stores which has self talked to
                //We can check if it's found in the talked to list.
                for (int i = 0; i < sellersStores.size(); i++) {
                    if (talkedTo.contains(sellersStores.get(i))) {
                        storesAlreadyTalked.addElement(sellersStores.get(i));
                    } else {
                        storesNotTalked.addElement(sellersStores.get(i));
                    }
                }
                changePage(SELECT_STORE_PAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void updateBlocking(String target) {
        String message;
        if (self.getRole().equals("C")) {
            message = "updateBlocking--" + self.getUsername() + "--" + target;
        } else {
            message = "updateBlocking--" + self.getCurrentStore() + "--" + target;
        }
        out.println(message);
        try {
            String reply = in.readLine();
            if (reply.equals("1") || reply.equals("3")) {
                currentBlockStatus.setText("You are currently blocking the conversation with " + target);
                blockButton.setSelected(true);
                blockButton.setText("Unblock");
            } else {
                currentBlockStatus.setText("You are not currently blocking this conversation with " + target);
                blockButton.setSelected(false);
                blockButton.setText("Block");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

    public void block(String target, int flag) {
        //flag -> 1 for block 2 for unblock
        String message;
        if (self.getRole().equals("C")) {
            message = "blocking--" + self.getUsername() + "--" + target + "--" + flag;
        } else {
            message = "blocking--" + self.getCurrentStore() + "--" + target + "--" + flag;
        }
        out.println(message);

        try {
            String reply = in.readLine();
            if (reply.equals("B")) {
                JOptionPane.showMessageDialog(null, "Successfully blocked!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                currentBlockStatus.setText("You are currently blocking the conversation with " + target);
                blockButton.setText("Unblock");
            } else {
                JOptionPane.showMessageDialog(null, "Successfully unblocked!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                currentBlockStatus.setText("You are not currently blocking the conversation with " + target);
                blockButton.setText("Block");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

    public void exportCSV(ArrayList<String> chat) throws IOException {
        //Sets the file name differently based on the role of the self user
        String csvFileName = "";
        if (self.getRole().equals("S")) {
            csvFileName = self.getCurrentStore() + "," + target + ".csv";
        } else if (self.getRole().equals("C")) {
            csvFileName = self.getUsername() + "," + target + ".csv";
        }

        //Create file and print writer to write to the csv file
        PrintWriter newThread = new PrintWriter(new FileWriter(csvFileName));

        //Add all lines of the ArrayList to the csv
        for (String s : chat) {
            newThread.println(s);
            newThread.flush();
        }
        newThread.close();
    }

    public void logout() {
        //get ip get port
        String ip = ipField.getText();
        String port = "";
        //send final logout command
        this.out.println("logout");
        self = null;
        firstRefresh = true;
        users.clear();
        currentChat = "";
        target = "";
        portTextField.setText("");
        loginPageUsernameField.setText("");
        loginPagePasswordField.setText("");
        signupPageUsernameField.setText("");
        signupPagePasswordField.setText("");
        signupPageStoreField.setText("");
        //First Store Page
        firstStoreText.setText("");
        addStoreText.setText("");
        removeStoreText.setText("");
        storeDropdownList.removeAllItems();
        stores = null;
        //Settings Page
        selectInvisibleBox.removeAllItems();
        hitListBox.removeAllItems();
        selectBlockBox.removeAllItems();
        blockedUserBox.removeAllItems();
        customersAlreadyTalked.removeAllElements();
        customersNotTalked.removeAllElements();
        customerList1.removeAll();
        customerList2.removeAll();
        storesAlreadyTalked.removeAllElements();
        storesNotTalked.removeAllElements();
        storesList1.removeAll();
        storesList2.removeAll();
        sendPanelPreviousConvo.setText("");
        sendPanelTextfield.setText("");
        deletePanelPreviousConvo.setText("");
        deletePageTextfield.setText("");
        editPanelPreviousConvo.setText("");
        editPageNumberTextfield.setText("");
        editPageMessageTextfield.setText("");
        importTextfield.setText("");
        currentBlockStatus.setText("");
        title.setText("");
        try {
            firstRefresh();
        } catch (IOException e) {
        } catch (ClassNotFoundException e) {
        }
    }

    /*
    MAIN
     */

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Client());
    }
}
